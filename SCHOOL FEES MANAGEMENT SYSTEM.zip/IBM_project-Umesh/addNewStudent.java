import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;

import java.sql.*;
import javax.swing.JComboBox;

public class addNewStudent extends JFrame implements ActionListener{
	JLabel scholarNo,name,fname,clas,mob,head,year;
	JTextField tscholarNo,tname,tfname,tmob;
	JButton back,submit;
	private  JPanel contentPane;
	private JComboBox<Integer> tclass;
	private JComboBox<Integer> tyear;
	private JLabel correct;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					addNewStudent frame = new addNewStudent();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public addNewStudent() {
		setLocation(200,100);
		setVisible(true);
		setSize(500,600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		getContentPane().setLayout(null);
		setResizable(false);
		setTitle("New New Student");
		getContentPane().setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


		scholarNo = new JLabel("Scholar No :");
		name = new JLabel("Name :");
		fname = new JLabel("Father Name :");
		clas = new JLabel("Class :");
		mob = new JLabel("Mobile Number:");
		head = new JLabel("New Student Registration");
		head.setHorizontalAlignment(SwingConstants.CENTER);
		head.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				head.setFont(new Font(Utility.HEAD_FONT_MOUSE, Font.BOLD, 20));
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_MOUSE_R,Utility.HEAD_FG_COLOR_MOUSE_G,Utility.HEAD_FG_COLOR_MOUSE_B));
			}
			@Override
			public void mouseExited(MouseEvent e) {
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
			}
		});
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));

		year = new JLabel("Enter current year");

		tscholarNo = new JTextField();

		tscholarNo.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char ch=e.getKeyChar();
				if(ch<48||ch>57) {
					e.consume();
				}
			}
			});
		tname = new JTextField();
		tname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				e.setKeyChar(Character.toUpperCase(e.getKeyChar()));
				char ch=e.getKeyChar();
				if(ch<64||ch>91) {
					e.consume();
				}
			}
		});
		tfname = new JTextField();
		tfname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				e.setKeyChar(Character.toUpperCase(e.getKeyChar()));
				char ch=e.getKeyChar();
				if(ch<64||ch>91) {
					e.consume();
				}
			}
		});
		tmob = new JTextField();
		tmob.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				String s = tmob.getText();
				if(s.length()!=10) {
					correct.setText("Please Enter valid mobile number");
				}
				else{
					correct.setText("");
				}
			}
		});
		tmob.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char ch=e.getKeyChar();
				if(ch<48||ch>57) {
					e.consume();
				}
			}
		});
		submit = new JButton("SUBMIT");

		contentPane.getRootPane().setDefaultButton(submit);
		submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		submit.setIcon(new ImageIcon(Img.SIGN_UP));
		back = new JButton("BACK");
		back.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					back.doClick();
				}
			}
		});
		back.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		back.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		back.setIcon(new ImageIcon(Img.SIGN_UP));



		contentPane.add(submit);
		contentPane.add(back);
		contentPane.add(scholarNo);
		contentPane.add(name);
		contentPane.add(fname);
		contentPane.add(clas);
		contentPane.add(mob);
		contentPane.add(head);
		contentPane.add(tscholarNo);
		contentPane.add(tname);
		contentPane.add(tfname);
		contentPane.add(tmob);
		contentPane.add(year);

		head.setBounds(0,20,470,40);
		scholarNo.setBounds(20,100,200,20);
		name.setBounds(20,140,200,20);
		fname.setBounds(20,180,200,20);
		clas.setBounds(20,220,200,20);
		mob.setBounds(20,260,200,20);
		year.setBounds(20,300,200,20);

		tscholarNo.setBounds(230,100,200,20);
		tname.setBounds(230,140,200,20);
		tfname.setBounds(230,180,200,20);
		tmob.setBounds(230,260,200,20);


		submit.setBounds(50,380,100,40);
		back.setBounds(300,380,100,40);
		
		tclass = new JComboBox<Integer>();
		tclass.setBounds(232, 219, 68, 22);
		getContentPane().add(tclass);
		
		for(int i = 0 ;i<13;i++)
		{
			tclass.addItem(i);
		}
		
		tyear = new JComboBox<Integer>();
		tyear.setBounds(230, 299, 70, 22);
		getContentPane().add(tyear);
		
		correct = new JLabel("");
		correct.setForeground(new Color(255, 0, 0));
		correct.setFont(new Font("Dialog", Font.PLAIN, 13));
		correct.setBounds(230, 280, 200, 16);
		getContentPane().add(correct);
		tyear.addItem(0);
		for(int i = 1950 ;i<2100;i++)
		{
			tyear.addItem(i);
		}
		submit.addActionListener(this);
		back.addActionListener(this);
		

	}
	public void actionPerformed(ActionEvent ev){
		if(ev.getSource()==submit){

			String dname = tname.getText();
			String dfname = tfname.getText();
			String dmob = tmob.getText();
			int dyear = (int)tyear.getSelectedItem();
			int dclass = (int)tclass.getSelectedItem();
			String dscholar = tscholarNo.getText();


			if(dscholar.isEmpty()){
				JOptionPane.showMessageDialog(this,"Please provide student Scholar No");
			}
			else if(!checkNum(dscholar)){
				JOptionPane.showMessageDialog(this,"Please provide valid student Scholar No.");
			}
			else if(dname.isEmpty()){
				JOptionPane.showMessageDialog(this,"Please provide student name");
			}
			else if(dfname.isEmpty()){
				JOptionPane.showMessageDialog(this,"Please provide student father name");
			}
			else if(dclass==0){
				JOptionPane.showMessageDialog(this,"Please select student class");
			}
			else if(dmob.isEmpty()){
				JOptionPane.showMessageDialog(this,"Please provide student Mobile Number");
			}
			else if(dyear==0){
				JOptionPane.showMessageDialog(this,"Please select current year");
			}
			else if(dmob.length()!=10) {
				JOptionPane.showMessageDialog(this,"Please Enter valid mobile number");
			}

			else{

				int asch = getNum(dscholar);
				int ayear = (dyear);
				int aclass =(dclass);
				try{
					 Class.forName(DbConstant.CLASS_NAME);
            	     Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	     Statement st = con.createStatement();

            	     try{
							System.out.println("try execute");
						String q = "CREATE TABLE student_"+ayear+"_"+aclass+
                   "(scholer_no INTEGER not NULL, " +
                   " student_name VARCHAR(255), " + 
                   " student_father_name VARCHAR(255), " + 
                   " student_mobile_no VARCHAR(255), " + 
                   " PRIMARY KEY ( scholer_no ))"; 
						st.executeUpdate(q);
						 throw new ArithmeticException("not valid");
					}
					catch(Exception e){
						 String q = "SELECT SCHOLER_NO FROM student_"+ayear+"_"+aclass;
						 ResultSet rs = st.executeQuery(q);
						 boolean f =true;
						 while(rs.next()){
						 	if(rs.getInt("scholer_no")==asch){
						 		f = false;
						 		JOptionPane.showMessageDialog(this,"Student already registered");
						 	}
						 }
						 if(f){
						 q = "insert into student_"+ayear+"_"+aclass+" values ( "+asch+" , '"+dname+"' , '"+dfname+"' , '"+dmob+ "' )";
						st.executeUpdate(q);
						JOptionPane.showMessageDialog(this,"Student register successfully");
						}

					}


					con.close();

				}
	
					 catch(Exception evv){
					System.out.println(evv);
				}
						



				}
				
			}
		else if(ev.getSource() == back){
			this.dispose();
			new AccountantLoginPage().setVisible(true);
		}

	}
	
	public boolean checkNum(String s){
		try{
			Integer.parseInt(s);
			return true;
		}
		catch(NumberFormatException e){
			return false;
		}
	}
	public int getNum(String s){
		return Integer.parseInt(s);
		
	}


}
