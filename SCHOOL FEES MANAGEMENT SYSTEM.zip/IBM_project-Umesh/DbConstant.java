
public class DbConstant {
	public static final String CLASS_NAME ="oracle.jdbc.driver.OracleDriver";
	public static final String CONNECTION = "jdbc:oracle:thin:@localhost:1521:xe";
	public static final String DATABASE_NAME = "projectIbm";
	public static final String DATABASE_PASSWORD = "Umesh";


	public static final String T_PRINCIPAL = "PRINCIPAL";
}

