import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JOptionPane;


class NewPrincipalForm extends JFrame implements ActionListener{
	
	JLabel head,name,father,mother,heighest,email,mob,securityQ,securityA;
	JTextField namet,fathert,mothert,heighestt,emailt,mobt,securityAt;
	JButton submit,cancle;
	String que[]={"What was your childhood nickname?",
				"In what city did you meet your spouse/significant other?",
				"What is the name of your favorite childhood friend?",
				"What street did you live on in third grade?",
				"What is your oldest sibling�s birthday month and year? (e.g., January 1900)"};

 
	JComboBox<String> securityQt;
	private JLabel mobc;

	NewPrincipalForm(){
		setResizable(false);
		setLocation(200,100);
		setTitle("New Principal Form");
		setLocation(200,100);
		setVisible(true);
		getContentPane().setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		getContentPane().setLayout(null);
		setSize(774,386);
		getContentPane().setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		submit = new JButton("SUBMIT");
		getRootPane().setDefaultButton(submit);
		submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		submit.setIcon(new ImageIcon(Img.SIGN_UP));
		cancle = new JButton("CANCLE");
		cancle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					cancle.doClick();
				}
			}
		});
		cancle.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		cancle.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		cancle.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		cancle.setIcon(new ImageIcon(Img.SIGN_UP));
		
		head = new JLabel(" FORM - NEW PRINCIPAL");
		head.setHorizontalAlignment(SwingConstants.CENTER);
		head.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				head.setFont(new Font(Utility.HEAD_FONT_MOUSE, Font.BOLD, 20));
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_MOUSE_R,Utility.HEAD_FG_COLOR_MOUSE_G,Utility.HEAD_FG_COLOR_MOUSE_B));
			}
			@Override
			public void mouseExited(MouseEvent e) {
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
			}
		});
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
		
		
		
		name = new JLabel("NAME : ");
		father = new JLabel("FATHER NAME : ");
		mother = new JLabel("MOTHER NAME : ");
		email = new JLabel("EMAIL ADDRESS : ");
		mob = new JLabel("MOBILE NO. : ");
		heighest = new JLabel("HEIGHEST QUALIFICATION : ");
		securityQ = new JLabel("SECURITY QUESTION : ");
		securityA = new JLabel("SECURITY ANSWER : ");
		namet = new JTextField();
		namet.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				e.setKeyChar(Character.toUpperCase(e.getKeyChar()));
				char ch=e.getKeyChar();
				if(ch<64||ch>91) {
					e.consume();
				}
			}
		});
		fathert = new JTextField();
		fathert.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				e.setKeyChar(Character.toUpperCase(e.getKeyChar()));
				char ch=e.getKeyChar();
				if(ch<64||ch>91) {
					e.consume();
				}
			}
		});
		mothert = new JTextField();
		mothert.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				e.setKeyChar(Character.toUpperCase(e.getKeyChar()));
				char ch=e.getKeyChar();
				if(ch<64||ch>91) {
					e.consume();
				}
			}
		});
		heighestt = new JTextField();
		emailt = new JTextField();
		mobt = new JTextField();
		securityAt = new JTextField();
		securityQt=new JComboBox(que); 


		mobt.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				String s = mobt.getText();
				if(s.length()<10||s.length()>10) {
					mobc.setText("Enter valid Mobile Number");
				}
				else{
					mobc.setText("");
				}
			}
		});
		mobt.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char ch=e.getKeyChar();
				if(ch<48||ch>57) {
					e.consume();
					getToolkit().beep();
				}
			}
		});






		getContentPane().add(submit);
		getContentPane().add(cancle);
		getContentPane().add(head);
		getContentPane().add(name);
		getContentPane().add(father);
		getContentPane().add(mother);
		getContentPane().add(heighest);
		getContentPane().add(email);
		getContentPane().add(mob);
		getContentPane().add(securityQ);
		getContentPane().add(securityA);
		getContentPane().add(securityAt);
		getContentPane().add(securityQt);
		getContentPane().add(namet);
		getContentPane().add(fathert);
		getContentPane().add(mothert);
		getContentPane().add(heighestt);
		getContentPane().add(emailt);
		getContentPane().add(mobt);
		




		head.setBounds(0,20,756,40);
		name.setBounds(20,80,92,20);
		namet.setBounds(124,80,159,20);
		father.setBounds(381,80,105,20);
		fathert.setBounds(498,80,200,20);
		mother.setBounds(381,113,105,20);
		mothert.setBounds(498,113,200,20);
		heighest.setBounds(309,146,177,20);
		heighestt.setBounds(498,146,200,20);
		email.setBounds(20,146,117,20);
		emailt.setBounds(124,146,159,20);
		mob.setBounds(20,113,92,20);
		mobt.setBounds(124,113,159,20);
		securityQ.setBounds(20,179,200,20);
		securityQt.setBounds(242,179,456,22);
		securityA.setBounds(20,212,200,20);
		securityAt.setBounds(242,211,200,20);
		submit.setBounds(54,265,100,40);
		cancle.setBounds(402,265,100,40);
		
		mobc = new JLabel("");
		mobc.setForeground(Color.RED);
		mobc.setFont(new Font("Tahoma", Font.PLAIN, 12));
		mobc.setBounds(124, 130, 159, 16);
		getContentPane().add(mobc);


		submit.addActionListener(this);
		cancle.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==submit){
			String dname = namet.getText();
			String dfname = fathert.getText();
			String dmname = mothert.getText();
			String dhq = heighestt.getText();
			String dmail = emailt.getText();
			String dmob = mobt.getText();
			String dsecQ = securityQt.getSelectedItem().toString();
			String dsecA = securityAt.getText();

			if(dname.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your Name");
			}
			else if(dfname.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your Father Name");
			}
			else if(dmname.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your Mother Name");
			}
			else if(dhq.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your Highest Qualification");
			}
			else if(dmail.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your valid E-mail");
			}
			else if(dmob.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your valid Mobile No.");
			}
			else if(dsecA.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your Security Answer");
			}
			else if(dmob.length()<10||dmob.length()>10){
					JOptionPane.showMessageDialog(this,"Enter valid Mobile Number");
			}
			else if(!dmail.contains("@")||!dmail.contains(".com")){
				JOptionPane.showMessageDialog(this,"Enter Correct mail Id");
			}
			else
			{
				this.dispose();
				new NewPrincipalCrediantial(dname,dfname,dmname,dhq,dmail,dmob,dsecQ,dsecA);
			}

		}
		else if(e.getSource()==cancle){
			this.dispose();
			new Principal_Login();
		}
	}
	public static void main(String args[]){
		new NewPrincipalForm();
	}

}