import java.awt.Color; 
import java.awt.Cursor;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import java.sql.*;

import java.util.ArrayList;
import javax.swing.JSeparator;
import javax.swing.SwingConstants; 

public class PSetFeeManagement extends JFrame {
	ArrayList<Data> list = new ArrayList<>();
	private class Data{
		private int clas;
		private int fee;
		Data(int cl,int fe){
			clas=cl;
			fee=fe;
			list.add(this);
		}
		
	}

	private JPanel contentPane;
	private JTextField t1;
	private JTextField t5;
	private JTextField t3;
	private JTextField t7;
	private JTextField t9;
	private JTextField t11;
	private JTextField t2;
	private JTextField t4;
	private JTextField t6;
	private JTextField t8;
	private JTextField t10;
	private JTextField t12;
	private JPanel panel_1;
	private JPanel panel_2;
	private int pyear=0;
	private JLabel l1;
	private JLabel l3;
	private JLabel l5;
	private JLabel l7;
	private JLabel l9;
	private JLabel l11;
	private JLabel l2;
	private JLabel l4;
	private JLabel l6;
	private JLabel l8;
	private JLabel l10;
	private JLabel l12;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PSetFeeManagement frame = new PSetFeeManagement();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PSetFeeManagement() {
		setTitle("FEE MANAGEMENT");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 753, 422);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		
		panel_1 = new JPanel();
		panel_1.setBounds(0, 113, 735, 262);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		panel_1.setVisible(false);
		panel_1.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		
		JLabel lblst = new JLabel("1st");
		lblst.setBounds(62, 56, 56, 16);
		panel_1.add(lblst);
		
		JLabel label = new JLabel("Class");
		label.setBounds(62, 24, 77, 16);
		panel_1.add(label);
		
		JLabel label_1 = new JLabel("Fee");
		label_1.setBounds(157, 24, 56, 16);
		panel_1.add(label_1);
		
		JLabel label_2 = new JLabel("Class");
		label_2.setBounds(439, 24, 77, 16);
		panel_1.add(label_2);
		
		JLabel label_3 = new JLabel("Fee");
		label_3.setBounds(534, 24, 56, 16);
		panel_1.add(label_3);
		
		t1 = new JTextField();
		t1.setColumns(10);
		t1.setBounds(157, 53, 116, 22);
		panel_1.add(t1);
		
		t5 = new JTextField();
		t5.setColumns(10);
		t5.setBounds(157, 112, 116, 22);
		panel_1.add(t5);
		
		JLabel label_4 = new JLabel("3rd");
		label_4.setBounds(62, 84, 56, 16);
		panel_1.add(label_4);
		
		t3 = new JTextField();
		t3.setColumns(10);
		t3.setBounds(157, 82, 116, 22);
		panel_1.add(t3);
		
		JLabel label_5 = new JLabel("5th");
		label_5.setBounds(62, 115, 56, 16);
		panel_1.add(label_5);
		
		JLabel label_6 = new JLabel("7th");
		label_6.setBounds(62, 143, 56, 16);
		panel_1.add(label_6);
		
		t7 = new JTextField();
		t7.setColumns(10);
		t7.setBounds(157, 140, 116, 22);
		panel_1.add(t7);
		
		t9 = new JTextField();
		t9.setColumns(10);
		t9.setBounds(157, 169, 116, 22);
		panel_1.add(t9);
		
		JLabel label_7 = new JLabel("9th");
		label_7.setBounds(62, 169, 56, 16);
		panel_1.add(label_7);
		
		JLabel label_8 = new JLabel("11th");
		label_8.setBounds(62, 200, 56, 16);
		panel_1.add(label_8);
		
		t11 = new JTextField();
		t11.setColumns(10);
		t11.setBounds(157, 197, 116, 22);
		panel_1.add(t11);
		
		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(534, 50, 116, 22);
		panel_1.add(t2);
		
		JLabel lblnd = new JLabel("2nd");
		lblnd.setBounds(439, 53, 56, 16);
		panel_1.add(lblnd);
		
		JLabel lblth = new JLabel("4th");
		lblth.setBounds(439, 81, 56, 16);
		panel_1.add(lblth);
		
		t4 = new JTextField();
		t4.setColumns(10);
		t4.setBounds(534, 79, 116, 22);
		panel_1.add(t4);
		
		t6 = new JTextField();
		t6.setColumns(10);
		t6.setBounds(534, 109, 116, 22);
		panel_1.add(t6);
		
		JLabel lblth_1 = new JLabel("6th");
		lblth_1.setBounds(439, 112, 56, 16);
		panel_1.add(lblth_1);
		
		JLabel lblth_2 = new JLabel("8th");
		lblth_2.setBounds(439, 140, 56, 16);
		panel_1.add(lblth_2);
		
		t8 = new JTextField();
		t8.setColumns(10);
		t8.setBounds(534, 137, 116, 22);
		panel_1.add(t8);
		
		t10 = new JTextField();
		t10.setColumns(10);
		t10.setBounds(534, 166, 116, 22);
		panel_1.add(t10);
		
		JLabel lblth_3 = new JLabel("10th");
		lblth_3.setBounds(439, 166, 56, 16);
		panel_1.add(lblth_3);
		
		JLabel lblth_4 = new JLabel("12th");
		lblth_4.setBounds(439, 197, 56, 16);
		panel_1.add(lblth_4);
		
		t12 = new JTextField();
		t12.setColumns(10);
		t12.setBounds(534, 194, 116, 22);
		panel_1.add(t12);
		
		JButton update = new JButton("UPDATE/ADD");
		update.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					update.doClick();
				}
			}
		});
		update.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		update.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		update.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		update.setIcon(new ImageIcon(Img.SIGN_UP));
		update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String z1 = t1.getText().toString();
				String z2 = t2.getText().toString();
				String z3 = t3.getText().toString();
				String z4 = t4.getText().toString();
				String z5 = t5.getText().toString();
				String z6 = t6.getText().toString();
				String z7 = t7.getText().toString();
				String z8 = t8.getText().toString();
				String z9 = t9.getText().toString();
				String z10 = t10.getText().toString();
				String z11 = t11.getText().toString();
				String z12 = t12.getText().toString();

				if(z1.isEmpty()||z2.isEmpty()||z3.isEmpty()
					||z4.isEmpty()||z5.isEmpty()||z6.isEmpty()
					||z7.isEmpty()||z8.isEmpty()||z9.isEmpty()
					||z10.isEmpty()||z11.isEmpty()||z12.isEmpty())
				{
					JOptionPane.showMessageDialog(panel_1,"Please fill all detail correctly!!");
				}
				else if(!checkNum(z1)||!checkNum(z2)||!checkNum(z3)
					||!checkNum(z4)||!checkNum(z5)||!checkNum(z6)
					||!checkNum(z7)||!checkNum(z8)||!checkNum(z9)
					||!checkNum(z10)||!checkNum(z11)||!checkNum(z12))
				{
					JOptionPane.showMessageDialog(panel_1,"please fill detail correctly.\nIn number form!");
				}
				else
				{
					try
          			{
            	   Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection( DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();

            	   list.clear();
            	   Data d = new Data(1,getNum(z1));
            	   Data d2= new Data(2,getNum(z2));
            	   Data d3= new Data(3,getNum(z3));
            	   Data d4= new Data(4,getNum(z4));
            	   Data d5= new Data(5,getNum(z5));
            	   Data d6= new Data(6,getNum(z6));
            	   Data d7= new Data(7,getNum(z7));
            	   Data d8= new Data(8,getNum(z8));
            	   Data d9= new Data(9,getNum(z9));
            	   Data d10= new Data(10,getNum(z10));
            	   Data d11 = new Data(11,getNum(z11));
            	   Data d12 = new Data(12,getNum(z12));
            	   
            	   for(int i =0 ;i<12;i++){
            	   	Data d1 = list.get(i);
            	   	String query= "update fee_structure_"+pyear+" set fee= "+list.get(i).fee+" where class = "+(i+1);
            	   	st.executeUpdate(query);
            	   }


            	   
            	   JOptionPane.showMessageDialog(panel_1,"FEE STRUCTURE UPDATE/ADD SUCCESSFULLY");
            	   
            	   con.close();
           			}	
           		catch(Exception ev){
           			System.out.println(ev);
           		}

				}
			}
		});
		update.setBounds(500, 229, 150, 25);
		panel_1.add(update);
		
		JPanel panel_0 = new JPanel();
		panel_0.setBounds(0, 0, 735, 113);
		contentPane.add(panel_0);
		panel_0.setLayout(null);
		
		JLabel lblFeeManagment = new JLabel("FEE MANAGEMENT");
		lblFeeManagment.setHorizontalTextPosition(SwingConstants.CENTER);
		lblFeeManagment.setBounds(12, 5, 723, 16);
		panel_0.add(lblFeeManagment);
		
		JComboBox year = new JComboBox();
		year.setBounds(185, 30, 99, 22);
		panel_0.add(year);
		for(int i=1950;i<2100;i++)
		{
			year.addItem(i);
		}
		
		JLabel lblSelectYear = new JLabel("SELECT YEAR");
		lblSelectYear.setBounds(40, 33, 107, 16);
		panel_0.add(lblSelectYear);
		panel_0.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		
		JButton view = new JButton("VIEW");
		view.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					view.doClick();
				}
			}
		});
		view.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		view.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		view.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		view.setIcon(new ImageIcon(Img.SIGN_UP));
		view.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel_1.setVisible(false);
				panel_2.setVisible(false);
				pyear = (int)year.getSelectedItem();
				list.clear();
				try{
					 Class.forName(DbConstant.CLASS_NAME);
            	     Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	     Statement st = con.createStatement();
            	     try{
            	     	String q = "SELECT * from Fee_structure_"+pyear ;
						 ResultSet rs = st.executeQuery(q);
						 
						 while(rs.next())
						 {
						 	new Data(rs.getInt("class"),rs.getInt("fee"));
						 }
						 l1.setText(String.valueOf(list.get(0).fee));
						 l2.setText(String.valueOf(list.get(1).fee));
						 l3.setText(String.valueOf(list.get(2).fee));
						 l4.setText(String.valueOf(list.get(3).fee));
						 l5.setText(String.valueOf(list.get(4).fee));
						 l6.setText(String.valueOf(list.get(5).fee));
						 l7.setText(String.valueOf(list.get(6).fee));
						 l8.setText(String.valueOf(list.get(7).fee));
						 l9.setText(String.valueOf(list.get(8).fee));
						 l10.setText(String.valueOf(list.get(9).fee));
						 l11.setText(String.valueOf(list.get(10).fee));
						 l12.setText(String.valueOf(list.get(11).fee));
						 list.clear();
						 panel_2.setVisible(true);

            	     }
            	     catch(Exception ee){
            	     	JOptionPane.showMessageDialog(panel_2,"Fee Structure not set for selected year !\n"+
            	     		"Please Add Fee Structure for selected year!!!");
            	     }
            	     con.close();
            	 }
            	 catch(Exception evv){
            	 	System.out.println(evv);
            	 }


			}
		});
		view.setBounds(393, 29, 97, 25);
		panel_0.add(view);
		
		JButton update1 = new JButton("UPDATE");
		update1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					update1.doClick();
				}
			}
		});
		update1.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		update1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		update1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		update1.setIcon(new ImageIcon(Img.SIGN_UP));
		update1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel_2.setVisible(false);
				panel_1.setVisible(true);
				pyear = (int)year.getSelectedItem();
				try{
					 Class.forName(DbConstant.CLASS_NAME);
            	     Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	     Statement st = con.createStatement();

            	     try{
						String q = "create table Fee_structure_"+pyear+" ( class integer not null, "+
                   										"fee integer not null,"+
                   										" PRIMARY KEY (class))";
						st.executeUpdate(q);
						for(int i=1;i<=12;i++){
							q = "insert into Fee_structure_"+pyear+" values ( "+i+", "+0+")";
							st.executeUpdate(q);

						}
						 throw new ArithmeticException("not valid");
					}
					catch(Exception ev){
						String q = "SELECT * from Fee_structure_"+pyear ;
						 ResultSet rs = st.executeQuery(q);

						 while(rs.next())
						 {
						 	int x= rs.getInt("class");
						 	int y= rs.getInt("fee");
						 	Data d = new Data(x,y);
						 	
						 }
						 t1.setText(String.valueOf(list.get(0).fee));
						 t2.setText(String.valueOf(list.get(1).fee));
						 t3.setText(String.valueOf(list.get(2).fee));
						 t4.setText(String.valueOf(list.get(3).fee));
						 t5.setText(String.valueOf(list.get(4).fee));
						 t6.setText(String.valueOf(list.get(5).fee));
						 t7.setText(String.valueOf(list.get(6).fee));
						 t8.setText(String.valueOf(list.get(7).fee));
						 t9.setText(String.valueOf(list.get(8).fee));
						 t10.setText(String.valueOf(list.get(9).fee));
						 t11.setText(String.valueOf(list.get(10).fee));
						 t12.setText(String.valueOf(list.get(11).fee));
						 list.clear();

					}
					con.close();
				}
					 catch(Exception evv){
					System.out.println(evv);
				}

				
				
			}
		});
		update1.setBounds(563, 29, 97, 25);
		panel_0.add(update1);
		
		JButton back = new JButton("BACK");
		back.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					back.doClick();
				}
			}
		});
		back.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		back.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		back.setIcon(new ImageIcon(Img.SIGN_UP));
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose1();
				new PrincipalLoginPage().setVisible(true);
			}
		});
		back.setBounds(34, 62, 97, 25);
		panel_0.add(back);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 112, 735, 1);
		panel_0.add(separator);
		
			panel_2 = new JPanel();
			panel_2.setBounds(0, 113, 735, 262);
			contentPane.add(panel_2);
			panel_2.setLayout(null);
			panel_2.setVisible(false);
			panel_2.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
			
			JLabel label_9 = new JLabel("Fee");
			label_9.setBounds(154, 23, 56, 16);
			panel_2.add(label_9);
			
			JLabel label_10 = new JLabel("Class");
			label_10.setBounds(59, 23, 77, 16);
			panel_2.add(label_10);
			
			JLabel label_11 = new JLabel("1st");
			label_11.setBounds(59, 55, 56, 16);
			panel_2.add(label_11);
			
			JLabel label_12 = new JLabel("3rd");
			label_12.setBounds(59, 83, 56, 16);
			panel_2.add(label_12);
			
			JLabel label_13 = new JLabel("5th");
			label_13.setBounds(59, 114, 56, 16);
			panel_2.add(label_13);
			
			JLabel label_14 = new JLabel("7th");
			label_14.setBounds(59, 142, 56, 16);
			panel_2.add(label_14);
			
			JLabel label_15 = new JLabel("9th");
			label_15.setBounds(59, 168, 56, 16);
			panel_2.add(label_15);
			
			JLabel label_16 = new JLabel("11th");
			label_16.setBounds(59, 199, 56, 16);
			panel_2.add(label_16);
			
			JLabel label_17 = new JLabel("Class");
			label_17.setBounds(436, 23, 77, 16);
			panel_2.add(label_17);
			
			JLabel label_18 = new JLabel("Fee");
			label_18.setBounds(531, 23, 56, 16);
			panel_2.add(label_18);
			
			JLabel label_19 = new JLabel("2nd");
			label_19.setBounds(436, 52, 56, 16);
			panel_2.add(label_19);
			
			JLabel label_20 = new JLabel("4th");
			label_20.setBounds(436, 80, 56, 16);
			panel_2.add(label_20);
			
			JLabel label_21 = new JLabel("6th");
			label_21.setBounds(436, 111, 56, 16);
			panel_2.add(label_21);
			
			JLabel label_22 = new JLabel("8th");
			label_22.setBounds(436, 139, 56, 16);
			panel_2.add(label_22);
			
			JLabel label_23 = new JLabel("10th");
			label_23.setBounds(436, 165, 56, 16);
			panel_2.add(label_23);
			
			JLabel label_24 = new JLabel("12th");
			label_24.setBounds(436, 196, 56, 16);
			panel_2.add(label_24);
			
			l1 = new JLabel("");
			l1.setFont(new Font("Arial Black", Font.BOLD, 13));
			l1.setBounds(154, 55, 118, 16);
			panel_2.add(l1);
			
			l3 = new JLabel("");
			l3.setFont(new Font("Arial Black", Font.BOLD, 13));
			l3.setBounds(154, 83, 118, 16);
			panel_2.add(l3);
			
			l5 = new JLabel("");
			l5.setFont(new Font("Arial Black", Font.BOLD, 13));
			l5.setBounds(154, 114, 118, 16);
			panel_2.add(l5);
			
			l7 = new JLabel("");
			l7.setFont(new Font("Arial Black", Font.BOLD, 13));
			l7.setBounds(154, 142, 118, 16);
			panel_2.add(l7);
			
			l9 = new JLabel("");
			l9.setFont(new Font("Arial Black", Font.BOLD, 13));
			l9.setBounds(154, 168, 118, 16);
			panel_2.add(l9);
			
			l11 = new JLabel("");
			l11.setFont(new Font("Arial Black", Font.BOLD, 13));
			l11.setBounds(154, 196, 118, 16);
			panel_2.add(l11);
			
			l2 = new JLabel("");
			l2.setFont(new Font("Arial Black", Font.BOLD, 13));
			l2.setBounds(531, 55, 118, 16);
			panel_2.add(l2);
			
			l4 = new JLabel("");
			l4.setFont(new Font("Arial Black", Font.BOLD, 13));
			l4.setBounds(531, 83, 118, 16);
			panel_2.add(l4);
			
			l6 = new JLabel("");
			l6.setFont(new Font("Arial Black", Font.BOLD, 13));
			l6.setBounds(531, 114, 118, 16);
			panel_2.add(l6);
			
			l8 = new JLabel("");
			l8.setFont(new Font("Arial Black", Font.BOLD, 13));
			l8.setBounds(531, 142, 118, 16);
			panel_2.add(l8);
			
			l10 = new JLabel("");
			l10.setFont(new Font("Arial Black", Font.BOLD, 13));
			l10.setBounds(531, 168, 118, 16);
			panel_2.add(l10);
			
			l12 = new JLabel("");
			l12.setFont(new Font("Arial Black", Font.BOLD, 13));
			l12.setBounds(531, 196, 118, 16);
			panel_2.add(l12);
	}
	
	public boolean checkNum(String s){
		try{
			Integer.parseInt(s);
			return true;
		}
		catch(NumberFormatException e){
			return false;
		}
	}
	public int getNum(String s){
		int i=Integer.parseInt(s);
		return i;
		
	}
	public void dispose1() {
		this.dispose();
	}
}
