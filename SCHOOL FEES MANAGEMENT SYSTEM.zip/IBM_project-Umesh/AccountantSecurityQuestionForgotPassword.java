
import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.EventQueue;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

import java.awt.Cursor;


class AccountantSecurityQuestionForgotPassword extends JFrame implements ActionListener{
	JButton submit,cancle;
	JTextField securityAnswert;
	JLabel head,securityQuestion,securityAnswer;
	String name;
	String que[]={"What was your childhood nickname?",
				"In what city did you meet your spouse/significant other?",
				"What is the name of your favorite childhood friend?",
				"What street did you live on in third grade?",
				"What is your oldest sibling�s birthday month and year? (e.g., January 1900)"};

 
	JComboBox securityQt;
	AccountantSecurityQuestionForgotPassword(String uname){
		setTitle("SECURITY QUESTION VERIFICATION");
		setResizable(false);
		setLocation(200,100);
		setVisible(true);
		setSize(685,318);
		getContentPane().setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		getContentPane().setLayout(null);
		this.name=uname;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		submit = new JButton("SUBMIT");
		getRootPane().setDefaultButton(submit);
		submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		submit.setIcon(new ImageIcon(Img.SIGN_UP));
		cancle = new JButton("CANCLE");
		cancle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					cancle.doClick();
				}
			}
		});
		cancle.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		cancle.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		cancle.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		cancle.setIcon(new ImageIcon(Img.SIGN_UP));
		securityQuestion = new JLabel("SECURITY QUESTION : ");
		securityAnswer = new JLabel(" SECURITY ANSWER : ");
		head = new JLabel("SECURITY QUESTION VERIFICATION");
		head.setHorizontalAlignment(SwingConstants.CENTER);
		head.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				head.setFont(new Font(Utility.HEAD_FONT_MOUSE, Font.BOLD, 20));
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_MOUSE_R,Utility.HEAD_FG_COLOR_MOUSE_G,Utility.HEAD_FG_COLOR_MOUSE_B));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
			}
		});
				head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		
		securityQt=new JComboBox(que); 
		securityQt.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		securityQt.setOpaque(false);
		securityQt.setMaximumRowCount(5);
		getContentPane().add(securityQt);
		securityAnswert = new JTextField();

		getContentPane().add(submit);
		getContentPane().add(cancle);
		getContentPane().add(securityQuestion);
		getContentPane().add(securityAnswer);
		getContentPane().add(head);
		
		getContentPane().add(securityAnswert);

		head.setBounds(26,20,633,40);
		securityQuestion.setBounds(20,100,200,20);
		securityAnswer.setBounds(20,140,200,20);
		
		securityAnswert.setBounds(181,140,456,20);
		submit.setBounds(391,192,100,40);
		cancle.setBounds(50,192,100,40);
		securityQt.setBounds(181,99,456,22);
		submit.addActionListener(this);
		cancle.addActionListener(this);



		
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==submit){
			String secQ = securityQt.getSelectedItem().toString();
			String securityA = securityAnswert.getText().toString();
			if(securityA.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your Security Answer");
			}
			else{
				try
          		{
            	   Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();
            	   String query= "select security_answer,security_question from accountant where user_name='"+name+"'";
            	   ResultSet rs = st.executeQuery(query);
            	   boolean flag=false;
            	   while(rs.next()){
            	   	String secu = rs.getString("security_answer");
            	   	String secuQ = rs.getString("security_question");
            	   	System.out.println(secu);
            	   	if(securityA.equals(secu)&&secQ.equals(secuQ)){
            	   		flag = true;
            	   		break;
            	   	}
            	   }

            	   if(flag){
            			con.close();
            	   		this.dispose();
            	   		new SetAccountantPasswordForgot(name);
            	   	}
            	   	else{
            	   		JOptionPane.showMessageDialog(this,"Wrong Security Answer");
            	   	}
            	   	con.close();
           		}	
           		catch(Exception ev){
           			System.out.println(ev);
           		}
           	}

		}
		else if(e.getSource()==cancle){
			this.dispose();
			new AccountantLogin();
		}
	}
	public static void main(String args[]){
		EventQueue.invokeLater(new Runnable()  {
			public void run() {
				try {
					AccountantSecurityQuestionForgotPassword frame = new AccountantSecurityQuestionForgotPassword("aaa");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}