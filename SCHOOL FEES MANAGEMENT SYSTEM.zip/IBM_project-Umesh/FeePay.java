import java.awt.BorderLayout;
import javax.swing.JOptionPane;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JSeparator;
import javax.swing.UIManager;
import javax.swing.border.MatteBorder;

public class FeePay extends JFrame {

	private JPanel contentPane;
	private JTextField scholar;
	private JComboBox clas;
	private JComboBox year;
	private JButton submit;
	private JButton back;
	private JPanel panel_0;
	private JPanel panel_1;
	private JLabel tname;
	private JLabel tscholar;
	private JLabel tfname;
	private JLabel tfee;
	private int pay = 0;
	private int totalFee =0;
	private JButton payFee;
	private JPanel panel_2;
	private JLabel head;
	private JLabel lblTotalAmount;
	private JLabel lblLeftAmount;
	private JLabel lblAmountToBe;
	private JLabel ltamount;
	private JLabel lleftamount;
	private JTextField payed;
	private int dsc =0;
	private int dye =0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FeePay frame = new FeePay();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FeePay() {
		setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		setTitle("FEE PAY");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 753, 422);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		panel_0 = new JPanel();
		panel_0.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		panel_0.setBounds(0, 0, 735, 110);
		contentPane.add(panel_0);
		panel_0.setLayout(null);
		panel_0.setVisible(true);
		
		JLabel label = new JLabel("FIND STUDENT DETAIL");
		label.setBounds(251, 4, 204, 16);
		panel_0.add(label);
		
		JLabel label_1 = new JLabel("Scholar No.");
		label_1.setBounds(12, 34, 66, 16);
		panel_0.add(label_1);
		
		scholar = new JTextField();
		scholar.setColumns(10);
		scholar.setBounds(101, 31, 116, 22);
		panel_0.add(scholar);
		scholar.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char ch=e.getKeyChar();
				if(ch<48||ch>57) {
					e.consume();
				}
			}
		});
		
		JLabel label_2 = new JLabel("Class");
		label_2.setBounds(261, 34, 66, 16);
		panel_0.add(label_2);
		
		clas = new JComboBox();
		clas.setBounds(339, 33, 56, 22);
		panel_0.add(clas);
		for(int i=1;i<13;i++)
		{
			clas.addItem(i);
		}
		
		JLabel label_3 = new JLabel("Year");
		label_3.setBounds(532, 34, 66, 16);
		panel_0.add(label_3);
		
		year = new JComboBox();
		year.setBounds(610, 31, 56, 22);
		panel_0.add(year);
		for(int i=1950;i<2100;i++)
		{
			year.addItem(i);
		}
		
		submit = new JButton("SUBMIT");
		contentPane.getRootPane().setDefaultButton(submit);
		submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		submit.setIcon(new ImageIcon(Img.SIGN_UP));
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dsc=0;
				dye=0;
				String dscholar = scholar.getText();
				int ddclass = (int)clas.getSelectedItem();
				int ddyear = (int)year.getSelectedItem();
				
				if(dscholar.isEmpty()){
				JOptionPane.showMessageDialog(panel_0,"Please provide student Scholar No");
				}
				else if(!checkNum(dscholar)){
				JOptionPane.showMessageDialog(panel_0,"Please provide valid student Scholar No.");
				}
				else
				{
					int ddscholar = Integer.parseInt(dscholar);
					dye=ddyear;
					dsc = ddscholar;
					try
          		{
            	   Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();
            	   
            	   String query= "select SCHOLER_NO from STUDENT_"+ddyear+"_"+ddclass;
            	   boolean f = false;
            	   try{
            	   		ResultSet rs = st.executeQuery(query);
            	   		while(rs.next()){
            	   			int user = rs.getInt("scholer_no");
            	   			if(user==ddscholar){
            	   				f=true;
            	   				break;
            	   			}
            	   		}
            	   }
            	   catch(Exception ev)
            	   {
            	   	f=false;
            	   }
            	   try
            	   {
            		   pay=0;
            		   query = "select amount_pay from studentfee_"+dscholar+"_"+ddyear;
            		   ResultSet rs = st.executeQuery(query);
            		   while(rs.next()) {
            			   pay+=rs.getInt("amount_pay");
            		   }
            	   }
            	   catch(Exception ev)
            	   {
            		   pay=0;
            	   }
            	   try
            	   {
            		   JOptionPane.showMessageDialog(panel_1,"If fee structure was not set than please first set fee structure ."
            		   		+ "\notherwise it is your responsiblity if it behave improper\n-----"
            		   		+ "GOOD LUCK");
            		   panel_1.setVisible(true);
            		   totalFee = 0;
            		   query = "select fee from fee_structure_"+ddyear+" where class = "+ddclass;
            		   //String query= "update fee_structure_"+pyear+" set fee= "+list.get(i).fee+" where class = "+(i+1);
            		   ResultSet rs = st.executeQuery(query);
            		   while(rs.next()) {
            			   totalFee=rs.getInt("fee");
            		   }
            	   }
            	   catch(Exception ev)
            	   {
            		   System.out.println("catch");
            		   totalFee=0;
            	   }
            	   
            	   
            	   
            	   if(f)
            	   {
            		   
            	   	String mname="";
            	   	String mfname="";
            	   	String mmob="";
            	   	int temppay=pay;
            	   
            	   		query = "select * from STUDENT_"+ddyear+"_"+ddclass+" where SCHOLER_NO = "+dscholar;
            	   		ResultSet rs = st.executeQuery(query);
            	   		while(rs.next()){
            	   			 mname = rs.getString("STUDENT_NAME");
            	   			 mfname = rs.getString("STUDENT_FATHER_NAME");
            	   			 mmob = rs.getString("STUDENT_MOBILE_NO");
            	   		}
            	   		tname.setText(mname);
            	   		tfname.setText(mfname);
            	   		tscholar.setText(String.valueOf(ddscholar));
            	   		tfee.setText(temppay+"/"+totalFee);
            	   		
            	   		
            	   		
            	   }
            	   else
            	   {
            	   	JOptionPane.showMessageDialog(panel_0,"Student not REGISTERED!!!!!!");
            	   }

            	  
            	   
            	   con.close();
            	   
           		}	
           		catch(Exception ev){
           			System.out.println(ev);
           		}


					

				}
				
				
				
				
				
			}
			
		});
		submit.setBounds(569, 71, 97, 25);
		panel_0.add(submit);
		
		back = new JButton("BACK");
		back.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					back.doClick();
				}
			}
		});
		back.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		back.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		back.setIcon(new ImageIcon(Img.SIGN_UP));
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose1();
				new AccountantLoginPage().setVisible(true);
			}
		});
		back.setBounds(12, 71, 97, 25);
		panel_0.add(back);
		
		JSeparator separator = new JSeparator();
		separator.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		separator.setBackground(Color.RED);
		separator.setFocusable(true);
		separator.setBounds(0, 109, 735, 1);
		panel_0.add(separator);
		
		panel_2 = new JPanel();
		panel_2.setBackground(new Color(200, 235, 235));
		panel_2.setVisible(false);
		panel_2.setBounds(0, 0, 735, 375);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		panel_2.setVisible(false);
		
		head = new JLabel("");
		head.setBounds(0, 13, 735, 53);
		panel_2.add(head);
		head.setHorizontalAlignment(SwingConstants.CENTER);
		head.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				head.setForeground(new Color(240, 54, 48));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				head.setForeground(new Color(48, 83, 240));
			}
		});
		head.setForeground(new Color(48, 83, 240));
		head.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 25));
		
		lblTotalAmount = new JLabel("TOTAL AMOUNT");
		lblTotalAmount.setBounds(127, 96, 170, 16);
		panel_2.add(lblTotalAmount);
		
		lblLeftAmount = new JLabel("LEFT AMOUNT");
		lblLeftAmount.setBounds(127, 145, 170, 16);
		panel_2.add(lblLeftAmount);
		
		lblAmountToBe = new JLabel("AMOUNT TO BE PAY");
		lblAmountToBe.setBounds(127, 199, 170, 16);
		panel_2.add(lblAmountToBe);
		
		ltamount = new JLabel("");
		ltamount.setBounds(522, 96, 170, 16);
		panel_2.add(ltamount);
		
		lleftamount = new JLabel("");
		lleftamount.setBounds(522, 145, 170, 16);
		panel_2.add(lleftamount);
		
		payed = new JTextField();
		payed.setBounds(522, 196, 170, 22);
		panel_2.add(payed);
		payed.setColumns(10);
		payed.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char ch=e.getKeyChar();
				if(ch<48||ch>57) {
					e.consume();
				}
			}
		});
		
		JButton btnPay = new JButton("PAY");
		btnPay.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					btnPay.doClick();
				}
			}
		});
		btnPay.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		btnPay.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnPay.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnPay.setIcon(new ImageIcon(Img.SIGN_UP));
		btnPay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int dscholar = dsc;
				int ddyear = dye ;
				
				int fpay = Integer.parseInt(payed.getText());
				System.out.println(totalFee+","+(pay+fpay));
				if(totalFee >= (pay+fpay)) {
				try
	          		{
	            	   Class.forName(DbConstant.CLASS_NAME);
	            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
	            	   Statement st = con.createStatement();
	            	   
	            	   try {
	            		   
	            		   String query = "create table studentfee_"+dscholar+"_"+ddyear+" (amount_pay integer,"+
	            				   			"date_of_amount_pay DATE)";
	            		   st.executeUpdate(query);
	            		  
	            	   }
	            	   catch(Exception eb) {
	            		   
	            	   }
	            	   	int dd =0;
						int mm =0;
						int yy =0;
						int sec=0;
						int hr =0;
						int min=0;

	            	   
	            	   Calendar cal = Calendar.getInstance();
	            	    dd = cal.get(cal.DATE);
	            	    mm = cal.get(cal.MONTH)+1;
	            	    yy = cal.get(cal.YEAR);
	            	    sec = cal.get(cal.SECOND);
	            	    hr = cal.get(cal.HOUR);
	            	    min = cal.get(cal.MINUTE);
	            	   
	            	   System.out.println(dd);

	            	   //tring  query = "insert into studentfee_"+dscholar+"_"+ddyear+" values ("+fpay+
	            		   			//",to_date('25/12/1999 15:10:5','DD/MM/YYYY HH24:MI:SS'))";

	            		String  query = "insert into studentfee_"+dscholar+"_"+ddyear+" values ("+fpay+
	            			   			",to_date('"+dd+"/"+mm+"/"+yy+" "+sec+":"+min+":"+hr+"','DD/MM/YYYY HH24:MI:SS'))";
	            			   			System.out.println(query);
	            	   st.executeUpdate(query);
	            	   System.out.println("try");
	            	   JOptionPane.showMessageDialog(panel_2, fpay+"Rs. Amount Payed  Successfully");
	            	   con.close();
						dispose1();
						new FeePay().setVisible(true);
					
	          		
					
				}
				catch(Exception ev) {

	            	   JOptionPane.showMessageDialog(panel_2, "Amount not payed-----\nTransection Failed");
				}
			}
			else {
				JOptionPane.showMessageDialog(panel_2, "Please Enter valid amount,"+
												" Fee Exeed the total FEE\n"+
												"Please Enter Rs"+(totalFee-pay)+" or less than this");
			}
			}
		});
		
		btnPay.setBounds(522, 275, 97, 25);
		panel_2.add(btnPay);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					btnBack.doClick();
				}
			}
		});
		btnBack.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		btnBack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnBack.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnBack.setIcon(new ImageIcon(Img.SIGN_UP));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose1();
				new FeePay().setVisible(true);
			}
		});
		btnBack.setBounds(149, 275, 97, 25);
		panel_2.add(btnBack);
		
		panel_1 = new JPanel();
		panel_1.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		panel_1.setBounds(0, 110, 735, 265);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		panel_1.setVisible(false);
		
		JLabel label_4 = new JLabel("Student Name");
		label_4.setBounds(132, 59, 91, 16);
		panel_1.add(label_4);
		
		JLabel lblStudentFeePay = new JLabel("STUDENT FEE PAY");
		lblStudentFeePay.setBounds(317, 13, 199, 16);
		panel_1.add(lblStudentFeePay);
		
		JLabel label_6 = new JLabel("Father Name");
		label_6.setBounds(464, 59, 91, 16);
		panel_1.add(label_6);
		
		tname = new JLabel("");
		tname.setFont(new Font("Arial Black", Font.BOLD, 14));
		tname.setBounds(255, 59, 167, 16);
		panel_1.add(tname);
		
		tfname = new JLabel("");
		tfname.setFont(new Font("Arial Black", Font.BOLD, 14));
		tfname.setBounds(610, 59, 167, 16);
		panel_1.add(tfname);
		
		JLabel label_9 = new JLabel("Scholar Number");
		label_9.setBounds(132, 108, 105, 16);
		panel_1.add(label_9);
		
		tscholar = new JLabel("");
		tscholar.setBounds(255, 108, 167, 16);
		panel_1.add(tscholar);
		
		JLabel lblFee = new JLabel("Fee");
		lblFee.setBounds(464, 108, 105, 16);
		panel_1.add(lblFee);
		
		tfee = new JLabel("");
		tfee.setBounds(587, 108, 167, 16);
		panel_1.add(tfee);
		
		payFee = new JButton("PAY FEE");
		payFee.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					payFee.doClick();
				}
			}
		});
		payFee.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		payFee.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		payFee.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		payFee.setIcon(new ImageIcon(Img.SIGN_UP));
		payFee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				panel_0.setVisible(false);
				panel_1.setVisible(false);
				panel_2.setVisible(true);
				ltamount.setText(String.valueOf(totalFee));
				lleftamount.setText(String.valueOf(totalFee-pay));
				head.setText(String.valueOf("STUDENT SCHOLAR NUMBER IS : "+dsc));
			}
		});
		payFee.setBounds(464, 170, 97, 25);
		panel_1.add(payFee);
	}
	public boolean checkNum(String s){
		try{
			Integer.parseInt(s);
			return true;
		}
		catch(NumberFormatException e){
			return false;
		}
	}
	public int getNum(String s){
		return Integer.parseInt(s);
		
	}
	public void dispose1() {
		this.dispose();
	}
}
