import java.awt.BorderLayout; 
import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.JSeparator;

public class PUpdateStudent extends JFrame {

	private JPanel contentPane;
	private JTextField tscholar;
	private JLabel head;
	private JLabel scholar;
	private JButton back;
	private JButton submit;
	private JLabel name;
	private JLabel fname;
	private JLabel scholarNo;
	private JLabel tscholarNo;
	private JLabel clas;
	private JLabel year;
	private JLabel mobile;
	private JLabel tyear;
	private JPanel panel_1;
	private JPanel panel_0;
	private JLabel dclas;
	
	private JLabel dyear;
	private JComboBox tdyear;
	private JComboBox tdclass;
	private JLabel tclass;

	private JButton PUpdateStudent;
	private JTextField tname;
	private JTextField tmob;
	private JTextField tfname;
	private JSeparator separator;
	private JLabel correct;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PUpdateStudent frame = new PUpdateStudent();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PUpdateStudent() {
		setTitle("UPDATE STUDENT DETAIL");
		setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 753, 422);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		panel_0 = new JPanel();
		panel_0.setBounds(0, 0, 735, 110);
		contentPane.add(panel_0);
		panel_0.setLayout(null);
		
		scholar = new JLabel("Scholar No.");
		scholar.setBounds(30, 30, 66, 16);
		panel_0.add(scholar);
		
		head = new JLabel("FIND STUDENT DETAIL");
		head.setBounds(247, 2, 224, 16);
		panel_0.add(head);
		
		tscholar = new JTextField();
		tscholar.setBounds(121, 27, 116, 22);
		panel_0.add(tscholar);
		tscholar.setColumns(10);


		tscholar.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char ch=e.getKeyChar();
				if(ch<48||ch>57) {
					e.consume();
				}
			}
			});
		
		back = new JButton("BACK");
		back.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					back.doClick();
				}
			}
		});
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose1();
				new PrincipalLoginPage().setVisible(true);
			}
		});
		back.setBounds(12, 57, 97, 25);
		panel_0.add(back);
		
		submit = new JButton("SUBMIT");
		contentPane.getRootPane().setDefaultButton(submit);
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String dscholar = tscholar.getText();
				int ddclass = (int)tdclass.getSelectedItem();
				int ddyear = (int)tdyear.getSelectedItem();
				if(dscholar.isEmpty()){
				JOptionPane.showMessageDialog(panel_0,"Please provide student Scholar No");
				}
				else if(!checkNum(dscholar)){
				JOptionPane.showMessageDialog(panel_0,"Please provide valid student Scholar No.");
				}
				else
				{
					int ddscholar = Integer.parseInt(dscholar);
					try
          		{
            	   Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();
            	   String query= "select SCHOLER_NO from STUDENT_"+ddyear+"_"+ddclass;
            	   boolean f = false;
            	   try{
            	   		ResultSet rs = st.executeQuery(query);
            	   		while(rs.next()){
            	   			int user = rs.getInt("scholer_no");
            	   			if(user==ddscholar){
            	   				f=true;
            	   				break;
            	   			}
            	   		}
            	   }
            	   catch(Exception ev)
            	   {
            	   	f=false;
            	   }
            	   if(f)
            	   {
            	   	String mname="";
            	   	String mfname="";
            	   	String mmob="";
            	   		query = "select * from STUDENT_"+ddyear+"_"+ddclass+" where SCHOLER_NO = "+dscholar;
            	   		ResultSet rs = st.executeQuery(query);
            	   		while(rs.next()){
            	   			 mname = rs.getString("STUDENT_NAME");
            	   			 mfname = rs.getString("STUDENT_FATHER_NAME");
            	   			 mmob = rs.getString("STUDENT_MOBILE_NO");
            	   		}
            	   		tname.setText(mname);
            	   		tfname.setText(mfname);
            	   		tscholarNo.setText(String.valueOf(ddscholar));
            	   		tclass.setText(String.valueOf(ddclass));
            	   		tyear.setText(String.valueOf(ddyear));
            	   		tmob.setText(mmob);
            	   		panel_1.setVisible(true);
            	   }
            	   else
            	   {
            	   	JOptionPane.showMessageDialog(panel_0,"Student not REGISTERED!!!!!!");
            	   }

            	  
            	   

            	   con.close();
           		}	
           		catch(Exception ev){
           			System.out.println(ev);
           		}


					

				}
				
				
				
				
				
			}
		});
		submit.setBounds(578, 57, 97, 25);
		panel_0.add(submit);
		
		dclas = new JLabel("Class");
		dclas.setBounds(263, 33, 66, 16);
		panel_0.add(dclas);
		
		dyear = new JLabel("Year");
		dyear.setBounds(482, 33, 66, 16);
		panel_0.add(dyear);
		
		tdclass = new JComboBox();
		tdclass.setBounds(341, 30, 41, 22);
		panel_0.add(tdclass);
		for(int i=1;i<13;i++)
		{
			tdclass.addItem(i);
		}
		
		tdyear = new JComboBox();
		tdyear.setBounds(602, 27, 56, 22);
		panel_0.add(tdyear);
		
		separator = new JSeparator();
		separator.setBounds(0, 109, 735, 1);
		panel_0.add(separator);
		for(int i=1950;i<2100;i++)
		{
			tdyear.addItem(i);
		}
		
		panel_1 = new JPanel();
		panel_1.setBounds(0, 110, 723, 269);
		contentPane.add(panel_1);
		panel_1.setVisible(false);;
		panel_1.setLayout(null);
		
		JLabel head1 = new JLabel("STUDENT DETAIL");
		head1.setBounds(242, 13, 105, 16);
		panel_1.add(head1);
		
		name = new JLabel("Student Name");
		name.setBounds(27, 59, 91, 16);
		panel_1.add(name);
		
		fname = new JLabel("Father Name");
		fname.setBounds(359, 59, 91, 16);
		panel_1.add(fname);
		
		scholarNo = new JLabel("Scholar Number");
		scholarNo.setBounds(27, 108, 105, 16);
		panel_1.add(scholarNo);
		
		tscholarNo = new JLabel("");
		tscholarNo.setFont(new Font("Arial Black", Font.BOLD, 14));
		tscholarNo.setBounds(150, 108, 167, 16);
		panel_1.add(tscholarNo);
		
		clas = new JLabel("Class");
		clas.setBounds(359, 108, 91, 16);
		panel_1.add(clas);
		
		tclass = new JLabel("");
		tclass.setFont(new Font("Arial Black", Font.BOLD, 14));
		tclass.setBounds(505, 108, 167, 16);
		panel_1.add(tclass);
		
		mobile = new JLabel("Mobile Number");
		mobile.setBounds(27, 159, 105, 16);
		panel_1.add(mobile);
		
		year = new JLabel("Year");
		year.setBounds(359, 159, 91, 16);
		panel_1.add(year);
		
		tyear = new JLabel("");
		tyear.setFont(new Font("Arial Black", Font.BOLD, 14));
		tyear.setBounds(505, 159, 167, 16);
		panel_1.add(tyear);
		
		PUpdateStudent = new JButton("UPDATE");
		PUpdateStudent.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					PUpdateStudent.doClick();
				}
			}
		});
		PUpdateStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int tempSc = Integer.parseInt(tscholarNo.getText());
				int tempy = Integer.parseInt(tyear.getText());
				int tempc = Integer.parseInt(tclass.getText());
				String tempn = tname.getText();
				String tempfn = tfname.getText();
				String tempm = tmob.getText();
				try
				{
			    	Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();
            	   String query = "update STUDENT_"+tempy+"_"+tempc+" set STUDENT_NAME = '"+tempn+"' , STUDENT_FATHER_NAME = '"+tempfn+"' , STUDENT_MOBILE_NO = '"+tempm+"' where SCHOLER_NO = "+tempSc;
            	   st.executeUpdate(query);
            	  
            	   
            	   	JOptionPane.showMessageDialog(panel_0,"Student update Successfully!!!");
            	   	panel_1.setVisible(false);
            	   	con.close();
				}
				catch(Exception evv)
				{
					System.out.println(evv);
				}
			
				
			}
		});
		PUpdateStudent.setBounds(512, 204, 97, 25);
		panel_1.add(PUpdateStudent);
		
		tname = new JTextField();
		tname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				e.setKeyChar(Character.toUpperCase(e.getKeyChar()));
				char ch=e.getKeyChar();
				if(ch<64||ch>91) {
					e.consume();
				}
			}
		});
		tname.setBounds(150, 56, 167, 22);
		panel_1.add(tname);
		tname.setColumns(10);
		
		tmob = new JTextField();
		tmob.setColumns(10);
		tmob.setBounds(150, 156, 167, 22);
		panel_1.add(tmob);
		tmob.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				String s = tmob.getText();
				if(s.length()!=10) {
					correct.setText("Please Enter valid mobile number");
				}
				else{
					correct.setText("");
				}
			}
		});
		tmob.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char ch=e.getKeyChar();
				if(ch<48||ch>57) {
					e.consume();
				}
			}
		});		
		tfname = new JTextField();
		tfname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				e.setKeyChar(Character.toUpperCase(e.getKeyChar()));
				char ch=e.getKeyChar();
				if(ch<64||ch>91) {
					e.consume();
				}
			}
		});
		tfname.setColumns(10);
		tfname.setBounds(505, 56, 167, 22);
		panel_1.add(tfname);


		contentPane.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		panel_0.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		panel_1.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B)); 
		
		correct = new JLabel("");
		correct.setForeground(Color.RED);
		correct.setBounds(150, 181, 197, 16);
		panel_1.add(correct);


		submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		submit.setIcon(new ImageIcon(Img.SIGN_UP));

		back.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		back.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		back.setIcon(new ImageIcon(Img.SIGN_UP));

		PUpdateStudent.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		PUpdateStudent.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		PUpdateStudent.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		PUpdateStudent.setIcon(new ImageIcon(Img.SIGN_UP));
	}
		
		
	public boolean checkNum(String s){
		try{
			Integer.parseInt(s);
			return true;
		}
		catch(NumberFormatException e){
			return false;
		}
	}
	public void dispose1() {
		this.dispose();
	}
	public int getNum(String s){
		return Integer.parseInt(s);
		
	}



}
