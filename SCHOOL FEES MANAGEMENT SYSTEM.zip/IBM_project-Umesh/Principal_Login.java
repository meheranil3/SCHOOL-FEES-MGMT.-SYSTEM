import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.sql.*;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.DropMode;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.TitledBorder;
import java.awt.Cursor;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.SwingConstants;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

class Principal_Login extends JFrame implements ActionListener{
	JButton submit;
	JLabel head;
	JTextField usert;
	JPasswordField passt;
	private JLabel label;
	private JLabel label_1;
	private JLabel lblNewLabel;
	private JLabel forgot;
	private JLabel newPrincipal;
	private JLabel backl;

	Principal_Login(){
		setResizable(false);
		setTitle("Principal Login");
		setLocation(200,100);
		setVisible(true);
		setSize(444,600);
		getContentPane().setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		submit = new JButton("Sign Up");
		getRootPane().setDefaultButton(submit);
		submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		submit.setIcon(new ImageIcon(Img.SIGN_UP));
		submit.setBounds(194, 427, 100, 20);
		getRootPane().setDefaultButton(submit);

		head = new JLabel(" PRINCIPAL LOGIN!!!");
		head.setHorizontalAlignment(SwingConstants.CENTER);
		head.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				head.setFont(new Font(Utility.HEAD_FONT_MOUSE, Font.BOLD, 20));
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_MOUSE_R,Utility.HEAD_FG_COLOR_MOUSE_G,Utility.HEAD_FG_COLOR_MOUSE_B));
			}
			@Override
			public void mouseExited(MouseEvent e) {
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
			}
		});
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));

		head.setBounds(39, 13, 374, 40);
		usert = new JTextField();
		usert.setBounds(160, 351, 200, 20);
		passt = new JPasswordField();
		passt.setBounds(160, 384, 200, 20);
		getContentPane().setLayout(null);


		getContentPane().add(submit);
		getContentPane().add(head);
		getContentPane().add(usert);
		getContentPane().add(passt);
		
		label = new JLabel("");
		label.setBounds(95, 61, 265, 256);
		label.setIcon(new ImageIcon(Img.LOGIN_LOGO));
		getContentPane().add(label);
		
		label_1 = new JLabel("");
		label_1.setBounds(134, 353, 24, 16);
		label_1.setIcon(new ImageIcon(Img.USERNAME));
		getContentPane().add(label_1);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(136, 386, 24, 18);
		lblNewLabel.setIcon(new ImageIcon(Img.PASSWORD));
		getContentPane().add(lblNewLabel);
		
		forgot = new JLabel("Fogot Password");
		forgot.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		forgot.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
			new PrincipalForgotPassword();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				forgot.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				forgot.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
			}
		});
		forgot.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		forgot.setFont(new Font("Tahoma", Font.PLAIN, 9));
		forgot.setBounds(293, 408, 67, 16);
		getContentPane().add(forgot);
		
		newPrincipal = new JLabel("Add new Principal");
		newPrincipal.setIcon(new ImageIcon(Img.OK));
		newPrincipal.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		newPrincipal.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		newPrincipal.setBackground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		newPrincipal.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				newPrincipal.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				newPrincipal.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
			new OldPrincipalCrediantial();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				newPrincipal.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				newPrincipal.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
		newPrincipal.setBounds(14, 495, 220, 16);
		getContentPane().add(newPrincipal);
		
		backl = new JLabel("Back");
		backl.setIcon(new ImageIcon(Img.OK));
		backl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backl.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		backl.setBackground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		backl.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				backl.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				backl.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
            new Main_activity();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				backl.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				backl.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
		backl.setBounds(12, 524, 80, 16);
		getContentPane().add(backl);

		submit.addActionListener(this);

	}	
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==submit){
			String userN = usert.getText().toString();
			String userP = new String(passt.getPassword());
			if(userN.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your user name");
			}
			else if(userP.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your Password");
			}
			else{
				try
          		{
            	   Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();

            	   String query = "create table principal("+
										"name varchar2(50),"+
										"father_name varchar2(50),"+
										"mother_name varchar2(50),"+
										"Highest_Qualification varchar2(50),"+
										"email varchar2(100),"+
										"security_Question varchar2(500),"+
										"security_Answer varchar2(1000),"+
										"user_name varchar2(100) not null primary key,"+
										"password varchar2(100)"+
										")"; 
					try{
						st.executeUpdate(query);
						query = "INSERT INTO principal VALUES ('Umesh' , 'xyz' , 'zyx' , "+
						"'undergraduate' , 'umeshdangrecha240@gmail.com' , "+
						"'What was your childhood nickname?' , "+
						"'Umesh' , 'Umesh' , 'Umesh' )";
						st.executeUpdate(query);
					}
					catch (Exception create){
					}
            	   query= "select user_name,password from PRINCIPAL";
            	   ResultSet rs = st.executeQuery(query);
            	   boolean flag=false;
            	   while(rs.next()){
            	   	String user = rs.getString("user_name");
            	   	String pass = rs.getString("password");
            	   	if(userN.equals(user)&&userP.equals(pass)){
            	   		flag = true;
            	   		break;
            	   	}
            	   }

            	   if(flag){
            	   		JOptionPane.showMessageDialog(this,"Successfully Login!");
            	   		this.dispose();
            	   		con.close();
            	   		new PrincipalLoginPage().setVisible(true);
            	   	}
            	   	else{
            	   		JOptionPane.showMessageDialog(this,"Wrong username and password");
            	   	}
            	   	con.close();
           		}	
           		catch(Exception ev){
           			System.out.println(ev+" umesh");
           		}
           	}	
		}
	}
	public void dispose1(){
		this.dispose();
	}
	public static void main(String args[]){
		new Principal_Login();
	}	


}