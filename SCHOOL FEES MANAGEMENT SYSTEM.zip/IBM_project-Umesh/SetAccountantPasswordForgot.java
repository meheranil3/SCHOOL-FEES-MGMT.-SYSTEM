import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

class SetAccountantPasswordForgot extends JFrame implements ActionListener{
	JButton submit,cancle;
	JLabel head,pass,conformpass;
	String name;
	private JPasswordField conformpasst;
	private JPasswordField passt;
	SetAccountantPasswordForgot(String name){
		setLocation(200,100);
		setVisible(true);
		getContentPane().setLayout(null);
		setResizable(false);
		setSize(685,318);
		getContentPane().setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));




		this.name=name;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


		submit = new JButton("SUBMIT");
		getRootPane().setDefaultButton(submit);
		submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		submit.setIcon(new ImageIcon(Img.SIGN_UP));
		cancle = new JButton("CANCLE");
		cancle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					cancle.doClick();
				}
			}
		});
		cancle.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		cancle.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		cancle.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		cancle.setIcon(new ImageIcon(Img.SIGN_UP));



		pass = new JLabel("PASSWORD : ");
		conformpass = new JLabel("CONFORM PASSWORD : ");
		head = new JLabel(" SET PASSWORD - PRINCIPAL");
		head.setHorizontalAlignment(SwingConstants.CENTER);
		head.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				head.setFont(new Font(Utility.HEAD_FONT_MOUSE, Font.BOLD, 20));
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_MOUSE_R,Utility.HEAD_FG_COLOR_MOUSE_G,Utility.HEAD_FG_COLOR_MOUSE_B));
			}
			@Override
			public void mouseExited(MouseEvent e) {
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
			}
		});
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
		getContentPane().add(submit);
		getContentPane().add(cancle);
		getContentPane().add(pass);
		getContentPane().add(head);
		getContentPane().add(conformpass);
		head.setBounds(0,13,655,40);
		pass.setBounds(124,66,200,20);
		conformpass.setBounds(124,99,200,20);
		submit.setBounds(159,154,100,40);
		cancle.setBounds(400,154,100,40);
		
		conformpasst = new JPasswordField();
		conformpasst.setBounds(337, 99, 200, 20);
		getContentPane().add(conformpasst);
		
		passt = new JPasswordField();
		passt.setBounds(336, 65, 200, 20);
		getContentPane().add(passt);
		submit.addActionListener(this);
		cancle.addActionListener(this);

		
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==submit){
			String Npass = new String(passt.getPassword());
			String NCpass = new String(conformpasst.getPassword());
			if(Npass.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter password first");
			}
			else if(NCpass.isEmpty()){
				JOptionPane.showMessageDialog(this,"Please conform your password");
			}
			else if(!Npass.equals(NCpass)){
				JOptionPane.showMessageDialog(this,"Password not match");
			}
			else{
				/*int i=0;
				char[] ch = NCpass.toCharArray();
				while(i<NCpass.length()){
					ch[i]+=458;
					i++;
				}
				System.out.println(NCpass);
				NCpass = String.valueOf(ch);
				System.out.println(NCpass);*/

				try
          		{
            	   Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();
            	   String query= "update accountant set password= '"+NCpass+"' where user_name = '"+name+"'";
            	   st.executeUpdate(query);
            	   JOptionPane.showMessageDialog(this,"Password successfully changed");
            	   con.close();
            	   this.dispose();
            	   new AccountantLogin();
            	   
           		}	
           		catch(Exception ev){
           			System.out.println(ev);
           		}





			}

		}
		else if(e.getSource()==cancle){
			this.dispose();
			new AccountantLogin();
		}
	}
	public static void main(String args[]){
		new SetAccountantPasswordForgot("umesh_user");
	}

}