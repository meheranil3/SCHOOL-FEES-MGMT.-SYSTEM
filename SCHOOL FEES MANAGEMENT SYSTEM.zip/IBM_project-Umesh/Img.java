
public class Img {
	public static final String FRAME_ICON="C:\\image\\logo1.png";
	public static final String MAIN_LOGO = "C:\\image\\logo.png";
	public static final String OK = "C:\\image\\ok.png";
	public static final String 	USERNAME= "C:\\image\\username.png";
	public static final String PASSWORD = "C:\\image\\password.png";
	public static final String SIGN_UP="C:\\image\\sign_up.png";
	public static final String LOGIN_LOGO = "C:\\image\\login_icon.png";
	public static final String ACCOUNTANT_LOGIN = "C:\\image\\accontant_Login.png";


}
