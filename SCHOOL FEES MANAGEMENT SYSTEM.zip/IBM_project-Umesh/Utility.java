public class Utility{

	public static final int BKCOLOR_R =130;
	public static final int BKCOLOR_G =250;
	public static final int BKCOLOR_B =216;

	public static final int BTNCOLOR_R = 255;
	public static final int BTNCOLOR_G = 255;
	public static final int BTNCOLOR_B = 200;
	
	public static final int HEAD_FG_COLOR_R= 48;
	public static final int HEAD_FG_COLOR_G= 83;
	public static final int HEAD_FG_COLOR_B= 240;
	public static final int HEAD_FG_COLOR_MOUSE_R= 255;
	public static final int HEAD_FG_COLOR_MOUSE_G= 0;
	public static final int HEAD_FG_COLOR_MOUSE_B= 0;

	public static final String HEAD_FONT_MOUSE = "Ink Free";
	public static final String HEAD_FONT = "Ink Free";


	public static final String LINK_FONT_MOUSE = "Ink Free";
	public static final int LINK_COLOR_MOUSE_R =255;
	public static final int LINK_COLOR_MOUSE_G =26;
	public static final int LINK_COLOR_MOUSE_B =15;

	public static final String LINK_FONT ="Kokila";
	public static final int LINK_COLOR_R =2;
	public static final int LINK_COLOR_G =26;
	public static final int LINK_COLOR_B =150;


			
}
/*
240 54 48


Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B
Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B

Utility.HEAD_FONT
Utility.HEAD_FONT_MOUSE


*/