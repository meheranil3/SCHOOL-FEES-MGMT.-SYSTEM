import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

class PricipalCrediantialNewAccountant extends JFrame implements ActionListener{
	JButton submit,cancle;
	JTextField usert;
	JLabel head,user,pass;
	private JPasswordField passt;

	PricipalCrediantialNewAccountant(){
		setLocation(200,100);
		setTitle("Principal-Crediantial");
		setVisible(true);
		setSize(685,318);
		getContentPane().setLayout(null);
		getContentPane().setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		getContentPane().setLayout(null);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		submit = new JButton("SUBMIT");
		getRootPane().setDefaultButton(submit);
		submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		submit.setIcon(new ImageIcon(Img.SIGN_UP));
		cancle = new JButton("CANCLE");
		cancle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					cancle.doClick();
				}
			}
		});
		cancle.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		cancle.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		cancle.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		cancle.setIcon(new ImageIcon(Img.SIGN_UP));
		user = new JLabel("USERNAME : ");
		pass = new JLabel("PASSWORD : ");
		head = new JLabel(" PRINCIPAL's CREDIANTIAL's ARE REQUIRED");
		head.setHorizontalAlignment(SwingConstants.CENTER);
		head.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				head.setFont(new Font(Utility.HEAD_FONT_MOUSE, Font.BOLD, 20));
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_MOUSE_R,Utility.HEAD_FG_COLOR_MOUSE_G,Utility.HEAD_FG_COLOR_MOUSE_B));
			}
			@Override
			public void mouseExited(MouseEvent e) {
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
			}
		});
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
		usert = new JTextField();

		getContentPane().add(submit);
		getContentPane().add(cancle);
		getContentPane().add(user);
		getContentPane().add(pass);
		getContentPane().add(head);
		getContentPane().add(usert);

		head.setBounds(0,20,679,40);
		user.setBounds(20,100,200,20);
		pass.setBounds(20,140,200,20);
		usert.setBounds(250,100,200,20);
		submit.setBounds(50,200,100,40);
		cancle.setBounds(300,200,100,40);
		
		passt = new JPasswordField();
		passt.setBounds(250, 139, 200, 22);
		getContentPane().add(passt);

		submit.addActionListener(this);
		cancle.addActionListener(this);



	}

	public void actionPerformed(ActionEvent e){
		if(e.getSource()==submit){
			String userN = usert.getText().toString();
			String userP = new String(passt.getPassword());
			if(userN.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your user name");
			}
			else if(userP.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your Password");
			}
			else{
				try
          		{
            	   Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();
            	   String query= "select user_name,password from principal";
            	   ResultSet rs = st.executeQuery(query);
            	   boolean flag=false;
            	   while(rs.next()){
            	   	String user = rs.getString("user_name");
            	   	String pass = rs.getString("password");
            	   	if(userN.equals(user)&&userP.equals(pass)){
            	   		flag = true;
            	   		break;
            	   	}
            	   }

            	   if(flag){
            	   		JOptionPane.showMessageDialog(this,"Successfully Login!");
            	   		this.dispose();
            	   		con.close();
            	   		new NewAccountantForm();
            	   	}
            	   	else{
            	   		JOptionPane.showMessageDialog(this,"Wrong username and password");
            	   	}
            	   	con.close();
           		}	
           		catch(Exception ev){
           			System.out.println(ev);
           		}
           	}


			
		}
		else if(e.getSource()==cancle){
			this.dispose();
			new AccountantLogin();
		}
	}
	public static void main(String args[]){
		new PricipalCrediantialNewAccountant();
	}

}