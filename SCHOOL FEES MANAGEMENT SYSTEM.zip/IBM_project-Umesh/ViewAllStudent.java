import java.awt.BorderLayout; 
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.border.TitledBorder;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.JSeparator;
public class ViewAllStudent extends JFrame {

	private JPanel contentPane;
	JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewAllStudent frame = new ViewAllStudent();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	String[][] data = new String[1][7];
	String[] columnNames = {"Sr. No.","Scholar No", "Name", "Father Name" ,"Fee Pay","Fee Left","Total Fee"}; 
	int totalFee = 0;
	long classTotalFee = 0;
	long classPayedFee = 0;
	long classLeftFee = 0;
	private JPanel panel;
	private JLabel totalAmount;
	private JLabel payedAmount;
	private JLabel leftAmount;
	private JScrollPane scrollPane;
	private JComboBox clas;
	private JComboBox year;
	private final JSeparator separator = new JSeparator();
	public ViewAllStudent() {
		setTitle("VIEW ALL STUDENT");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 739, 581);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton submit = new JButton("SUBMIT");
		contentPane.getRootPane().setDefaultButton(submit);
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//panel.remove(table);
				//panel.repaint();
				scrollPane.revalidate();

				int tclass = (int)clas.getSelectedItem();
				int tyear = (int)year.getSelectedItem();
				data =new String[countData("student_"+tyear+"_"+tclass)][7];
				try
          		{
            	   Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();
            	   try {
            		   String query = "select fee from fee_structure_"+tyear+" where class = "+tclass;
            		   ResultSet rs = st.executeQuery(query);
            		  while( rs.next()){
            		   totalFee = rs.getInt("fee");
            	   		}
            	   
            	   		}
            	   		catch(Exception ec){
            	   			JOptionPane.showMessageDialog(contentPane,"Please first set Fee Structure"+
            	   				"\n Othervice this program will miss-behave");
            	   			totalFee = 0;
            	   		}
            	   		String query= "select STUDENT_NAME,STUDENT_FATHER_NAME,SCHOLER_NO from student_"+tyear+"_"+tclass;
            	   		try {
            	   			ResultSet rs =  st.executeQuery(query);
            	   			for(int i=0;rs.next();i++){
            	   				//data[i][0]=String.valueOf(i+1);
            					data[i][1] = rs.getString("SCHOLER_NO");
            	   				data[i][2] = rs.getString("STUDENT_NAME");
            	   				data[i][3] = rs.getString("STUDENT_FATHER_NAME");
            	   			}
							for(int i=0;i<data.length;i++){
            	   				int fp =0;
            	   				try{
            	   				
            	   				query = "select AMOUNT_PAY from STUDENTFEE_"+data[i][1]+"_"+tyear;
            	   				rs = st.executeQuery(query);
            		  			for(;rs.next();){
            		   				fp+= Integer.parseInt(rs.getString("AMOUNT_PAY"));
            	   					}
								}
					    		catch(Exception evv ){
					    			fp = 0;
            	   				}
            	   				data[i][4]=String.valueOf(fp);
            	   				data[i][5]=String.valueOf((totalFee-fp));
            	   				data[i][6]=String.valueOf(totalFee);
            	   				classTotalFee+=totalFee;
            	   				classPayedFee+=fp;
            	   				classLeftFee+=(totalFee-fp);
            	   				fp=0;
								}

								totalFee=0;
            	   				totalAmount.setText(String.valueOf(classTotalFee));
            	   				payedAmount.setText(String.valueOf(classPayedFee));
            	   				leftAmount.setText(String.valueOf(classLeftFee));
								classTotalFee=0;
								classLeftFee=0;
								classPayedFee=0;
						

								data = sortData(data);
								table = new JTable(data,columnNames);
								scrollPane.setViewportView(table);
            	  				panel.setVisible(true);
            	   				con.close();
							}
            	  		 catch(Exception ev) {
            				JOptionPane.showMessageDialog(contentPane,"YOU Enter wrong data");
            	   		}
            	   		
            	   		con.close();
            	   
           		}	
           		catch(Exception ev){
           			System.out.println(ev);
           		}
				
				
				
				
				
				
				
			}
		});
		
		submit.setBounds(574, 77, 97, 25);
		contentPane.add(submit);
		
		JLabel lblClass = new JLabel("Class");
		lblClass.setBounds(30, 32, 109, 16);
		contentPane.add(lblClass);
		
		clas = new JComboBox();
		clas.setBounds(151, 29, 54, 22);
		contentPane.add(clas);
		for(int i=1;i<13;i++){
			clas.addItem(i);
		}
		
		JLabel lblYear = new JLabel("Year");
		lblYear.setBounds(446, 32, 73, 16);
		contentPane.add(lblYear);
		
		year = new JComboBox();
		year.setBounds(607, 29, 64, 22);
		contentPane.add(year);
		
		JButton back = new JButton("BACK");
		back.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					back.doClick();
				}
			}
		});
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose1();
				new AccountantLoginPage().setVisible(true);
			}
		});
		back.setBounds(30, 77, 97, 25);
		contentPane.add(back);
			for(int i=1950;i<2100;i++){
			year.addItem(i);
		}	
		
		contentPane.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		
				panel = new JPanel();
				panel.setBounds(0, 134, 721, 400);
				contentPane.add(panel);
				panel.setVisible(false);
				panel.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(0, 0, 721, 271);
				panel.add(scrollPane);
				
				table = new JTable(data,columnNames);
				scrollPane.setViewportView(table);
				table.setColumnSelectionAllowed(true);
				table.setCellSelectionEnabled(true);
				table.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
				table.setRowHeight(20);
				
				JLabel ltotalAmount = new JLabel("Total Amount");
				ltotalAmount.setFont(new Font("Arial Black", Font.BOLD, 18));
				ltotalAmount.setBounds(12, 290, 188, 25);
				panel.add(ltotalAmount);
				
				JLabel lpayedAmount = new JLabel("Payed Amount");
				lpayedAmount.setFont(new Font("Arial Black", Font.BOLD, 18));
				lpayedAmount.setBounds(12, 325, 188, 25);
				panel.add(lpayedAmount);
				
				JLabel lleftAmount = new JLabel("Left Amount");
				lleftAmount.setFont(new Font("Arial Black", Font.BOLD, 18));
				lleftAmount.setBounds(12, 360, 188, 25);
				panel.add(lleftAmount);
				
				totalAmount = new JLabel("");
				totalAmount.setForeground(Color.ORANGE);
				totalAmount.setFont(new Font("Cambria Math", Font.BOLD, 20));
				totalAmount.setBounds(297, 296, 184, 25);
				panel.add(totalAmount);
				
				payedAmount = new JLabel("");
				payedAmount.setForeground(new Color(0, 128, 0));
				payedAmount.setFont(new Font("Cambria Math", Font.BOLD, 20));
				payedAmount.setBounds(297, 331, 184, 25);
				panel.add(payedAmount);
				
				leftAmount = new JLabel("");
				leftAmount.setForeground(Color.RED);
				leftAmount.setFont(new Font("Cambria Math", Font.BOLD, 20));
				leftAmount.setBounds(297, 366, 184, 25);
				panel.add(leftAmount);


				submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
				submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
				submit.setIcon(new ImageIcon(Img.SIGN_UP));
		
				back.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
				back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				back.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
				back.setIcon(new ImageIcon(Img.SIGN_UP));


				panel.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
				separator.setBounds(0, 110, 721, 1);
				contentPane.add(separator);
	}
	
	int countData(String a){
		int count = 0;
		try{
			Class.forName(DbConstant.CLASS_NAME);
            Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT COUNT(*) AS COUNT FROM "+a);
            while(rs.next()) {
    			count = rs.getInt("COUNT");
 				}		
 				con.close();
         }
         catch(Exception e){

         }
         return count;
	}
	public int getNum(String s){
		return Integer.parseInt(s);
		
	}
	public static  String[][] sortData(String ab[][]){
		String a[][] =ab;
		String [][] c = new String[1][a[0].length];
		int i=0;
		for(i=0;i<a.length-1;i++){
			for(int j=i+1;j<a.length;j++){
				if(Integer.parseInt(a[i][1])>Integer.parseInt(a[j][1])){
					c[0]=a[i];
					a[i]=a[j];
					a[j]=c[0];

				}
				
			}
			a[i][0]=String.valueOf(i+1);
			
		}
		a[i][0]=String.valueOf(i+1);
		return a;
	}
	public void dispose1() {
		this.dispose();
	}
}
