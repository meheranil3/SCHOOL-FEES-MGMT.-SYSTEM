import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.CardLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import java.sql.*;
import javax.swing.JComboBox;
import javax.swing.JSeparator;
import javax.swing.JTable;


public class StudentFeeDetail extends JFrame {

	private JPanel contentPane;
	private JTextField scholar;
	private JTable table;
	private JComboBox clas;
	private JComboBox year;
	private JButton back;
	private JButton submit;
	private JLabel name;
	private JLabel fname;
	private JPanel panel_1;
	private String data[][] = new String[1][3];
	private String column[] = {"SR. NO.","AMOUNT PAY","DATE"};
	private JScrollPane scrollPane;
	private JLabel lblTotalFee;
	private JLabel lblFeePayed;
	private JLabel lblFeeLeft;
	private JLabel tfee;
	private JLabel pfee;
	private JLabel lfee;
	private JSeparator separator;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentFeeDetail frame = new StudentFeeDetail();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudentFeeDetail() {
		setTitle("STUDENT FEE DETAIL");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 821, 566);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel_0 = new JPanel();
		panel_0.setBounds(0, 0, 803, 95);
		contentPane.add(panel_0);
		panel_0.setLayout(null);
		
		JLabel lblScholarNo = new JLabel("Scholar No");
		lblScholarNo.setBounds(29, 25, 95, 16);
		panel_0.add(lblScholarNo);
		
		scholar = new JTextField();
		scholar.addKeyListener(new KeyAdapter() {
			
			public void keyTyped(KeyEvent e) {
				char ch=e.getKeyChar();
				if(ch<48||ch>57) {
					e.consume();
				}
			}
		});
		scholar.setBounds(142, 22, 116, 22);
		panel_0.add(scholar);
		scholar.setColumns(10);
		
		JLabel nnnn = new JLabel("Class");
		nnnn.setBounds(319, 25, 56, 16);
		panel_0.add(nnnn);
		
		clas = new JComboBox();
		clas.setBounds(416, 22, 43, 22);
		panel_0.add(clas);
		for(int i=1;i<13;i++){
			clas.addItem(i);
		}
		
		JLabel lblYear = new JLabel("Year");
		lblYear.setBounds(546, 25, 56, 16);
		panel_0.add(lblYear);
		
		year = new JComboBox();
		year.setBounds(659, 22, 63, 22);
		panel_0.add(year);
		for(int i=1950;i<2100;i++){
			year.addItem(i);
		}
		back = new JButton("BACK");
		back.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					back.doClick();
				}
			}
		});
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose1();
				new AccountantLoginPage().setVisible(true);
			}
		});
		back.setBounds(29, 57, 97, 25);
		panel_0.add(back);
		
		submit = new JButton("SUBMIT");
		contentPane.getRootPane().setDefaultButton(submit);
		
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int tscholar = -1;
				panel_1.setVisible(false);
				tscholar = Integer.parseInt(scholar.getText());
				int tclass = (int)clas.getSelectedItem();
				int tyear = (int)year.getSelectedItem();
				if(tscholar<0){
					JOptionPane.showMessageDialog(panel_0,"Please provide Scholar Number");
				}
				else{
					int totalFee =0;
					try
          			{
            	   		Class.forName(DbConstant.CLASS_NAME);
            	   		Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   		Statement st = con.createStatement();
            	   		String query= "select SCHOLER_NO from STUDENT_"+tyear+"_"+tclass;
            	   		boolean f = false;


            	   		try {
            		  	 String query1 = "select fee from fee_structure_"+tyear+" where class = "+tclass;
            		   	ResultSet rs = st.executeQuery(query1);
            		  	while( rs.next()){
            		   totalFee = rs.getInt("fee");
            	   		}
            	   
            	   		}
            	   		catch(Exception ec){
            	   			JOptionPane.showMessageDialog(contentPane,"Please first set Fee Structure"+
            	   				"\n Othervice this program will miss-behave");
            	   			totalFee = 0;
            	   		}


            	   		try{
            	   			ResultSet rs = st.executeQuery(query);
            	   			while(rs.next()){
            	   				int user = rs.getInt("scholer_no");
            	   				if(user==tscholar){
            	   					f=true;
            	   					break;
            	   				}
            	   			}
            	   		}
            	   		catch(Exception ev)
            	   		{
            	   			f=false;
            	   		}
            	   		if(f)
            	   		{
            	   		query = "select * from STUDENT_"+tyear+"_"+tclass+" where SCHOLER_NO = "+tscholar;
            	   		ResultSet rs = st.executeQuery(query);
            	   		while(rs.next()){
            	   			 name.setText(rs.getString("STUDENT_NAME"));
            	   			 fname.setText(rs.getString("STUDENT_FATHER_NAME"));
            	   		}
            	   		try{
            	   			data = new String[countData("STUDENTFEE_"+tscholar+"_"+tyear)][3];
							query = "select * from STUDENTFEE_"+tscholar+"_"+tyear;
							rs = st.executeQuery(query);
							int i=0;
							int sum=0;
							while(rs.next())
							{
								i++;
								data[i-1][0]=String.valueOf(i);
								data[i-1][1]=rs.getString("AMOUNT_PAY");
								data[i-1][2]=rs.getString("DATE_OF_AMOUNT_PAY");
								sum+=rs.getInt("AMOUNT_PAY");
							}

							tfee.setText(String.valueOf(totalFee));
							pfee.setText(String.valueOf(sum));
							lfee.setText(String.valueOf((totalFee-sum)));
							table = new JTable(data,column);
            	  			scrollPane.setViewportView(table);
            	  			panel_1.setVisible(true);
						}
						catch(Exception notPay){
							JOptionPane.showMessageDialog(panel_1,"Student not pay fee ");
						}




						
            	   }
            	   else
            	   {
            	   	JOptionPane.showMessageDialog(panel_0,"Student not REGISTERED!!!!!!");
            	   }


            	   con.close();
				}
				catch(Exception eb){}
				
				
				
				
				
				}
			}
		});
		submit.setBounds(625, 57, 97, 25);
		panel_0.add(submit);
		
		panel_1 = new JPanel();
		panel_1.setBounds(0, 95, 803, 425);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		panel_1.setVisible(false);
		
		JLabel lblNewLabel = new JLabel("Student Detail");
		lblNewLabel.setBounds(291, 13, 207, 16);
		panel_1.add(lblNewLabel);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(41, 63, 56, 16);
		panel_1.add(lblName);
		
		name = new JLabel("");
		name.setBounds(156, 63, 112, 16);
		panel_1.add(name);
		
		fname = new JLabel("");
		fname.setBounds(576, 63, 112, 16);
		panel_1.add(fname);
		
		JLabel lblFatherName = new JLabel("Father Name");
		lblFatherName.setBounds(424, 63, 93, 16);
		panel_1.add(lblFatherName);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 124, 803, 160);
		panel_1.add(scrollPane);
		
		table = new JTable(data,column);
		scrollPane.setViewportView(table);
		
		lblTotalFee = new JLabel("Total Fee");
		lblTotalFee.setFont(new Font("Arial Black", Font.BOLD, 18));
		lblTotalFee.setBounds(41, 300, 144, 25);
		panel_1.add(lblTotalFee);
		
		lblFeePayed = new JLabel("Fee Payed");
		lblFeePayed.setFont(new Font("Arial Black", Font.BOLD, 18));
		lblFeePayed.setBounds(41, 345, 144, 25);
		panel_1.add(lblFeePayed);
		
		lblFeeLeft = new JLabel("Fee left");
		lblFeeLeft.setFont(new Font("Arial Black", Font.BOLD, 18));
		lblFeeLeft.setBounds(41, 390, 144, 25);
		panel_1.add(lblFeeLeft);
		
		tfee = new JLabel("");
		tfee.setForeground(new Color(250, 128, 114));
		tfee.setFont(new Font("Arial Black", Font.BOLD, 15));
		tfee.setBounds(304, 306, 178, 16);
		panel_1.add(tfee);
		
		pfee = new JLabel("");
		pfee.setForeground(new Color(0, 128, 0));
		pfee.setBackground(new Color(0, 128, 0));
		pfee.setFont(new Font("Arial Black", Font.BOLD, 15));
		pfee.setBounds(304, 351, 178, 16);
		panel_1.add(pfee);
		
		lfee = new JLabel("");
		lfee.setForeground(new Color(255, 0, 0));
		lfee.setBackground(new Color(255, 0, 0));
		lfee.setFont(new Font("Arial Black", Font.BOLD, 15));
		lfee.setBounds(304, 396, 178, 16);
		panel_1.add(lfee);

		contentPane.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		panel_0.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		
		separator = new JSeparator();
		separator.setBounds(0, 94, 803, 1);
		panel_0.add(separator);
		panel_1.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		scrollPane.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		table.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		
		submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		submit.setIcon(new ImageIcon(Img.SIGN_UP));

		back.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		back.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		back.setIcon(new ImageIcon(Img.SIGN_UP));
	}
	int countData(String a){
		int count = 0;
		try{
			Class.forName(DbConstant.CLASS_NAME);
            Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT COUNT(*) AS COUNT FROM "+a);
            while(rs.next()) {
    			count = rs.getInt("COUNT");
 				}		
 				con.close();
         }
         catch(Exception e){

         }
         return count;
	}
	public void dispose1() {
		this.dispose();
	}
}
