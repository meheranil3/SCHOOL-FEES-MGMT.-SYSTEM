import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.EventQueue;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JOptionPane;

class AccountantForgotPassword extends JFrame implements ActionListener{
	JButton submit,back;
	JLabel head;
	JTextField usert;
	private JLabel label;

	AccountantForgotPassword(){
		setResizable(false);
		setLocation(200,100);
		setVisible(true);
		setSize(451,249);
		getContentPane().setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		getContentPane().setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		submit = new JButton("SUBMIT");
		submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		submit.setIcon(new ImageIcon(Img.SIGN_UP));
		submit.setBounds(194, 427, 100, 20);
		getRootPane().setDefaultButton(submit);
		back = new JButton("BACK");
		back.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					back.doClick();
				}
			}
		});
		head = new JLabel(" FORGOT PASSWORD - ACCOUNTANT");
		head.setHorizontalAlignment(SwingConstants.CENTER);
		head.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_MOUSE_R,Utility.HEAD_FG_COLOR_MOUSE_G,Utility.HEAD_FG_COLOR_MOUSE_B));
				head.setFont(new Font(Utility.HEAD_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
				head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
			}
		});
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));

		usert = new JTextField();



		getContentPane().add(submit);
		getContentPane().add(back);
		getContentPane().add(head);
		getContentPane().add(usert);


		submit.setBounds(50,149,100,40);
		back.setBounds(279,149,100,40);
		head.setBounds(20,23,380,40);
		usert.setBounds(96,98,200,20);
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(Img.USERNAME));
		label.setBounds(68, 100, 24, 16);
		getContentPane().add(label);


		submit.addActionListener(this);
		back.addActionListener(this);
		back.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		back.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		back.setIcon(new ImageIcon(Img.SIGN_UP));
		


		
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==submit){
			String userN = usert.getText().toString();
			if(userN.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your user name");
			}
			else{
				try
          		{
            	   Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();
            	   String query= "select user_name from accountant";
            	   ResultSet rs = st.executeQuery(query);
            	   boolean flag=false;
            	   while(rs.next()){
            	   	String user = rs.getString("user_name");
            	   	if(userN.equals(user)){
            	   		flag = true;
            	   		break;
            	   	}
            	   }

            	   if(flag){
            			con.close();
            	   		this.dispose();
            	   		new AccountantSecurityQuestionForgotPassword(userN);
            	   	}
            	   	else{
            	   		JOptionPane.showMessageDialog(this,"Wrong username");
            	   	}
            	   	con.close();
           		}	
           		catch(Exception ev){
           			System.out.println(ev);
           		}
           	}

		}
		else if(e.getSource()==back){
			this.dispose();
			new AccountantLogin();
		}
		
		//getRootPane().setDefaultButton(submit);
	}

		public static void main(String args[]){
		EventQueue.invokeLater(new Runnable()  {
			public void run() {
				try {
					AccountantForgotPassword frame = new AccountantForgotPassword();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}