import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

class NewPrincipalCrediantial extends JFrame implements ActionListener{
	JButton submit,cancle;
	JTextField usert,confirmusert;
	JLabel head,user,pass,confirmpass,confirmuser;
	String dname, dfname, dmname, dhq, dmail, dmob, dsecQ, dsecA;
	private JPasswordField passt;
	private JPasswordField confirmpasst;
	
	NewPrincipalCrediantial(String dname,String dfname,String dmname,String dhq,String dmail,String dmob,String dsecQ,String dsecA){
		setLocation(200,100);
		setVisible(true);
		setTitle("New Principal Crediantial");
		setSize(774,386);
		getContentPane().setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		setResizable(false);
		getContentPane().setLayout(null);
		this.dfname=dfname;
		this.dmname=dmname;
		this.dhq=dhq;
		this.dmail=dmail;
		this.dmob=dmob;
		this.dsecA=dsecA;
		this.dsecQ=dsecQ;
		this.dname=dname;

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		submit = new JButton("SUBMIT");
		getRootPane().setDefaultButton(submit);
		submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		submit.setIcon(new ImageIcon(Img.SIGN_UP));
		cancle = new JButton("CANCLE");
		cancle.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					cancle.doClick();
				}
			}
		});
		cancle.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		cancle.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		cancle.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		cancle.setIcon(new ImageIcon(Img.SIGN_UP));
		
		
		user = new JLabel("USERNAME : ");
		pass = new JLabel("PASSWORD : ");
		confirmuser = new JLabel("CONFIRM USERNAME : ");
		confirmpass = new JLabel("CONFIRM PASSWORD : ");
		head = new JLabel(" SET USERNAME AND PASSWORD - NEW PRINCIPAL");
		head = new JLabel(" FORM - NEW PRINCIPAL");
		head.setHorizontalAlignment(SwingConstants.CENTER);
		head.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				head.setFont(new Font(Utility.HEAD_FONT_MOUSE, Font.BOLD, 20));
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_MOUSE_R,Utility.HEAD_FG_COLOR_MOUSE_G,Utility.HEAD_FG_COLOR_MOUSE_B));
			}
			@Override
			public void mouseExited(MouseEvent e) {
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
			}
		});
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
		
		
		
		usert = new JTextField();
		confirmusert = new JTextField();

		getContentPane().add(submit);
		getContentPane().add(cancle);
		getContentPane().add(user);
		getContentPane().add(pass);
		getContentPane().add(head);
		getContentPane().add(usert);
		getContentPane().add(confirmusert);
		getContentPane().add(confirmpass);
		getContentPane().add(confirmuser);

		head.setBounds(120,20,400,40);
		user.setBounds(20,100,90,20);
		confirmuser.setBounds(346,100,155,20);
		usert.setBounds(120,100,200,20);
		confirmusert.setBounds(513,100,200,20);
		pass.setBounds(20,150,90,20);
		confirmpass.setBounds(346,150,155,20);


		submit.setBounds(120,224,100,40);
		cancle.setBounds(513,224,100,40);
		
		passt = new JPasswordField();
		passt.setBounds(120, 149, 200, 20);
		getContentPane().add(passt);
		
		confirmpasst = new JPasswordField();
		confirmpasst.setBounds(513, 149, 200, 20);
		getContentPane().add(confirmpasst);

		submit.addActionListener(this);
		cancle.addActionListener(this);



		
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==submit){
			String Nuser = usert.getText().toString();
			String NCuser = new String(confirmusert.getText());
			String Npass = new String(passt.getPassword());
			String NCpass = new String(confirmpasst.getPassword());
			if(Nuser.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your USERNAME");
			}
			else if(NCuser.isEmpty()){
				JOptionPane.showMessageDialog(this,"Please confirm your username");
			}
			else if(Npass.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter password first");
			}
			else if(NCpass.isEmpty()){
				JOptionPane.showMessageDialog(this,"Please confirm your password");
			}
			else if(!Nuser.equals(NCuser)){
				JOptionPane.showMessageDialog(this,"username not match");
			}
			else if(!Npass.equals(NCpass)){
				JOptionPane.showMessageDialog(this,"Password not match");
			}
			else{
				try
          		{
            	   Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();
            	   st.executeUpdate("truncate table principal");
            	   String query= "insert into principal values ('"+dname+"','"
            	   												+dfname+"','"
            	   												+dmname+"','"
            	   												+dhq+"','"
            	   												+dmail+"','"
            	 
            	   												+dsecQ+"','"
            	   												+dsecA+"','"
            	   												+NCuser+"','"
            	   												+NCpass+"')";
            	   st.executeUpdate(query);
            	   JOptionPane.showMessageDialog(this,"Added Successfully");
            	   con.close();
            	   this.dispose();
            	   new Principal_Login();
           		}	
           		catch(Exception ev){
           			System.out.println(ev);
           		}





			}

		}
		else if(e.getSource()==cancle){
			this.dispose();
			new Principal_Login();
		}
	}
	public static void main(String args[]){
		new NewPrincipalCrediantial("cx","dsf","sf","sfd","fgs","sfd","sf","Sfg");
	}

}