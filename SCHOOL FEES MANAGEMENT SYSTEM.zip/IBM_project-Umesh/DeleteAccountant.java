import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.CardLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import java.sql.*;
import javax.swing.JComboBox;
import javax.swing.JSeparator;

public class DeleteAccountant extends JFrame {

	private JPanel contentPane;
	private JTextField uname;
	private JLabel head;
	private JLabel scholar;
	private JButton back;
	private JButton submit;
	private JLabel tname;
	private JLabel name;
	private JLabel fname;
	private JLabel tfname;
	private JLabel scholarNo;
	private JLabel email;
	private JLabel mname;
	private JLabel year;
	private JLabel tmob;
	private JLabel mobile;
	private JLabel tuname;
	private JButton delete;
	private JPanel panel_1;
	private JPanel panel_0;
	private JLabel tmname;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteAccountant frame = new DeleteAccountant();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DeleteAccountant() {
		setBackground(Color.WHITE);
		setTitle("DELETE ACCOUNTANT");
		setResizable(false);
		getContentPane().setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 753, 422);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		
		panel_0 = new JPanel();
		panel_0.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		panel_0.setBounds(0, 0, 747, 108);
		contentPane.add(panel_0);
		panel_0.setLayout(null);
		
		scholar = new JLabel("User Name");
		scholar.setBounds(442, 30, 79, 16);
		panel_0.add(scholar);
		
		head = new JLabel("DELETE ACCOUNTANT");
		head.setBounds(280, 1, 145, 16);
		panel_0.add(head);
		
		uname = new JTextField();
		uname.setBounds(533, 27, 142, 22);
		panel_0.add(uname);
		
		uname.setColumns(10);
		
		back = new JButton("BACK");
		back.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					back.doClick();
				}
			}
		});
		back.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		back.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		back.setIcon(new ImageIcon(Img.SIGN_UP));
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose1();
				new PrincipalLoginPage().setVisible(true);
			}
		});
		back.setBounds(12, 57, 97, 25);
		panel_0.add(back);
		
		submit = new JButton("SUBMIT");
		contentPane.getRootPane().setDefaultButton(submit);
		submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		submit.setIcon(new ImageIcon(Img.SIGN_UP));
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nameu = uname.getText();
				
				if(nameu.isEmpty()){
				JOptionPane.showMessageDialog(panel_0,"Please provide Accountant user name");
				}
				else
				{
				try
          		{
            	   Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();
            	   String query= "select USER_NAME from ACCOUNTANT";
            	   boolean f = false;
            	   try{
            	   		ResultSet rs = st.executeQuery(query);

            	   		while(rs.next()){
            	   			
            	   			String user = rs.getString("USER_NAME").toString();
            	   			
            	   			if(user.equals(nameu)){
            	   				f=true;
            	   				break;
            	   			}
            	   		}
            	   }
            	   catch(Exception ev)
            	   {
            	   	f=false;
            	   }
            	   if(f)
            	   {
            	   	String mname="";
            	   	String mfname="";
            	   	String mmob="";
            	   	String mmname="";
            	   	String mmail = "";
            	   	
            	   		query = "select * from Accountant where USER_NAME = '"+nameu+"'";
            	   		ResultSet rs = st.executeQuery(query);

            	   		while(rs.next()){
            	   			 mname = rs.getString("NAME");
            	   			 mfname = rs.getString("FATHER_NAME");
            	   			 mmname=rs.getString("MOTHER_NAME");
            	   			 mmail = rs.getString("EMAIL");
            	   		}            	   		tname.setText(mname);
            	   		tfname.setText(mfname);
            	   		email.setText(String.valueOf(mmail));
            	   		tmname.setText(String.valueOf(mmname));
            	   		tuname.setText(String.valueOf(nameu));
						panel_1.setVisible(true);
            	   }
            	   else
            	   {
            	   	JOptionPane.showMessageDialog(panel_0,"Wrong Accountant User Name!!!!!!");
            	   }

            	  
            	   
            	   con.close();
            	   
           		}	
           		catch(Exception ev){
           			System.out.println(ev);
           		}



				}
				
				
				
				
				
			}
		});
		submit.setBounds(578, 57, 97, 25);
		panel_0.add(submit);
		
		JSeparator separator = new JSeparator();
		separator.setBackground(Color.DARK_GRAY);
		separator.setBounds(0, 107, 747, 1);
		panel_0.add(separator);
		
		
		panel_1 = new JPanel();
		panel_1.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		panel_1.setBounds(0, 108, 748, 280);
		contentPane.add(panel_1);
		panel_1.setVisible(false);;
		panel_1.setLayout(null);
		
		JLabel head1 = new JLabel("ACCOUNTANT DETAIL");
		head1.setBounds(242, 13, 246, 16);
		panel_1.add(head1);
		
		name = new JLabel("Accountant Name");
		name.setBounds(12, 59, 106, 16);
		panel_1.add(name);
		
		fname = new JLabel("Father Name");
		fname.setBounds(359, 59, 91, 16);
		panel_1.add(fname);
		
		tname = new JLabel("");
		tname.setFont(new Font("Arial Black", Font.BOLD, 14));
		tname.setBounds(150, 59, 167, 16);
		panel_1.add(tname);
		
		tfname = new JLabel("");
		tfname.setFont(new Font("Arial Black", Font.BOLD, 14));
		tfname.setBounds(505, 59, 167, 16);
		panel_1.add(tfname);
		
		scholarNo = new JLabel("Email Addresss");
		scholarNo.setBounds(27, 108, 105, 16);
		panel_1.add(scholarNo);
		
		email = new JLabel("");
		email.setFont(new Font("Arial Black", Font.BOLD, 14));
		email.setBounds(150, 108, 167, 16);
		panel_1.add(email);
		
		mname = new JLabel("Mother Name");
		mname.setBounds(359, 108, 91, 16);
		panel_1.add(mname);
		
		tmname = new JLabel("");
		tmname.setFont(new Font("Arial Black", Font.BOLD, 14));
		tmname.setBounds(505, 108, 167, 16);
		panel_1.add(tmname);
		
		mobile = new JLabel("Mobile Number");
		mobile.setBounds(27, 159, 105, 16);
		panel_1.add(mobile);
		
		tmob = new JLabel("");
		tmob.setFont(new Font("Arial Black", Font.BOLD, 14));
		tmob.setBounds(150, 159, 167, 16);
		panel_1.add(tmob);
		
		year = new JLabel("User name");
		year.setBounds(359, 159, 91, 16);
		panel_1.add(year);
		
		tuname = new JLabel("");
		tuname.setFont(new Font("Arial Black", Font.BOLD, 14));
		tuname.setBounds(505, 159, 167, 16);
		panel_1.add(tuname);
		
		delete = new JButton("DELETE ACCOUNTANT");
		delete.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER) {
					delete.doClick();
				}
			}
		});
		delete.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		delete.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		delete.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		delete.setIcon(new ImageIcon(Img.SIGN_UP));
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userN = uname.getText();
				
				try
				{
			    	Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();
            	   String query= "delete from accountant where USER_NAME = '"+userN+"'";
            	   st.executeUpdate(query);
            	   	JOptionPane.showMessageDialog(panel_0,"Accountant Deleted Successfully!!!");
            	   	panel_1.setVisible(false);
            	   	con.close();
				}
				catch(Exception evv)
				{
					System.out.println(evv);
				}
				
				
				
				
				
				
			}
		});
		delete.setBounds(477, 218, 195, 25);
		panel_1.add(delete);
	}
	public boolean checkNum(String s){
		try{
			Integer.parseInt(s);
			return true;
		}
		catch(NumberFormatException e){
			return false;
		}
	}
	public void dispose1() {
		this.dispose();
	}
	public int getNum(String s){
		return Integer.parseInt(s);
		
	}
}
