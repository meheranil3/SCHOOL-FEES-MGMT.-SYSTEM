
import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

public class Main_activity extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable()  {
			public void run() {
				try {
					Main_activity frame = new Main_activity();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main_activity() {
		
		setTitle("Fee Managment");
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Img.FRAME_ICON));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		setLocation(200,100);
		setVisible(true);
		setSize(339,401);
		
		
		
		ImageIcon image = new ImageIcon("C:\\image\\logo.png");
		JLabel label = new JLabel(image);
		label.setBounds(12, 48, 250, 237);
		getContentPane().add(label);
		
		JLabel head;
		head = new JLabel("STUDENT FEE MANAGMENT");
		head.setBounds(12, 13, 302, 35);
		head.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				head.setFont(new Font(Utility.HEAD_FONT_MOUSE, Font.BOLD, 20));
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_MOUSE_R,Utility.HEAD_FG_COLOR_MOUSE_G,Utility.HEAD_FG_COLOR_MOUSE_B));
			}
			@Override
			public void mouseExited(MouseEvent e) {
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
			}
		});
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
		
		head.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
		head.setHorizontalAlignment(SwingConstants.CENTER);
		head.setHorizontalTextPosition(SwingConstants.CENTER);
		contentPane.add(head);
		
		JLabel principal = new JLabel("Principal Login");
		principal.setIcon(new ImageIcon(Img.OK));
		principal.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		principal.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		principal.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
		principal.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
				new Principal_Login();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				principal.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				principal.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				principal.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				principal.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
		principal.setBounds(10, 309, 184, 21);
		contentPane.add(principal);
		
		
		JLabel accountant = new JLabel("Accountant Login");
		accountant.setIcon(new ImageIcon(Img.OK));
		accountant.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		accountant.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		accountant.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
		accountant.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
				new AccountantLogin();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				accountant.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				accountant.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				accountant.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				accountant.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
		accountant.setBounds(12, 332, 193, 21);
		contentPane.add(accountant);
	
	}
	public void dispose1(){
		this.dispose();
	}

}
