import java.awt.BorderLayout; 
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.border.TitledBorder;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.JSeparator;
public class ViewAllAccountant extends JFrame {

	private JPanel contentPane;
	JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewAllAccountant frame = new ViewAllAccountant();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	String[][] data;
	String[] columnNames = {"Sr. No.","User Name", "Name", "Father Name" ,"Mother Name","E-Mail"}; 
	int totalFee = 0;
	long classTotalFee = 0;
	long classPayedFee = 0;
	long classLeftFee = 0;
	private JPanel panel;
	private JScrollPane scrollPane;
	private JLabel head;
	public ViewAllAccountant() {
		setResizable(false);
		setTitle("VIEW ALL ACCOUNTANT");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 739, 469);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
			
		
		contentPane.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		
				panel = new JPanel();
				panel.setBounds(0, 86, 721, 335);
				contentPane.add(panel);
				panel.setLayout(null);
				
				data = new String[countData("accountant")][6];
				try
          		{
            	   Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();
            	   String query = "select * from Accountant";
            	   ResultSet rs = st.executeQuery(query);
            	   int i = 0;
            	   while(rs.next()){
            	   	data[i][0]=String.valueOf(i+1);
            	   	data[i][1]=rs.getString("User_name");
            	   	data[i][2]=rs.getString("name");
            	   	data[i][3]=rs.getString("father_name");
            	   	data[i][4]=rs.getString("mother_name");
            	   	data[i][5]=rs.getString("email");
            	   	i++;
            	   }
            	   con.close();

            	}
            	catch(Exception e){
            		JOptionPane.showMessageDialog(this,"No Accountant is added");
            	}

				scrollPane = new JScrollPane();
				scrollPane.setBounds(0, 0, 721, 271);
				panel.add(scrollPane);
				
				table = new JTable(data,columnNames);
				scrollPane.setViewportView(table);
				table.setColumnSelectionAllowed(true);
				table.setCellSelectionEnabled(true);
				table.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
				table.setRowHeight(20);


				panel.setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
				
				JButton back = new JButton("BACK");
				back.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent e) {
						if(e.getKeyChar()==KeyEvent.VK_ENTER) {
							back.doClick();
						}
					}
				});
				back.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
				back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				back.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
				back.setIcon(new ImageIcon(Img.SIGN_UP));
				back.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose1();
						new PrincipalLoginPage().setVisible(true);
					}
				});
				back.setBounds(10, 284, 97, 25);
				panel.add(back);
				
				head = new JLabel("All Accountant List");
				head.setBounds(40, 13, 549, 55);
				contentPane.add(head);
				head.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseEntered(MouseEvent e) {
						head.setFont(new Font(Utility.HEAD_FONT_MOUSE, Font.BOLD, 20));
						head.setForeground(new Color(Utility.HEAD_FG_COLOR_MOUSE_R,Utility.HEAD_FG_COLOR_MOUSE_G,Utility.HEAD_FG_COLOR_MOUSE_B));
					}
					@Override
					public void mouseExited(MouseEvent e) {
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
				head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
					}
				});
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
				head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
				
				head.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
				head.setHorizontalAlignment(SwingConstants.CENTER);
				head.setHorizontalTextPosition(SwingConstants.CENTER);
	}
	
	int countData(String a){
		int count = 0;
		try{
			Class.forName(DbConstant.CLASS_NAME);
            Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT COUNT(*) AS COUNT FROM "+a);
            while(rs.next()) {
    			count = rs.getInt("COUNT");
 				}		
 				con.close();
         }
         catch(Exception e){

         }
         return count;
	}
	public int getNum(String s){
		return Integer.parseInt(s);
		
	}
	public static  String[][] sortData(String ab[][]){
		String a[][] =ab;
		String [][] c = new String[1][a[0].length];
		int i=0;
		for(i=0;i<a.length-1;i++){
			for(int j=i+1;j<a.length;j++){
				if(Integer.parseInt(a[i][1])>Integer.parseInt(a[j][1])){
					c[0]=a[i];
					a[i]=a[j];
					a[j]=c[0];

				}
				
			}
			a[i][0]=String.valueOf(i+1);
			
		}
		a[i][0]=String.valueOf(i+1);
		return a;
	}
	public void dispose1() {
		this.dispose();
	}
}
