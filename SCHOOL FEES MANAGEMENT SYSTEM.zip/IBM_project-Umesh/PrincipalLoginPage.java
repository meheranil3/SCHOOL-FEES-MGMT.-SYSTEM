import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PrincipalLoginPage extends JFrame {

	private JPanel contentPane;
	private JLabel ans;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PrincipalLoginPage frame = new PrincipalLoginPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PrincipalLoginPage() {
		setResizable(false);
		setTitle("Principal Login Page");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 480, 565);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		getContentPane().setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		
		JLabel head= new JLabel("PRINCIPAL PAGE");
		head.setBounds(0, 13, 477, 36);
		contentPane.add(head);
		head.setHorizontalAlignment(SwingConstants.CENTER);
		head.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				head.setFont(new Font(Utility.HEAD_FONT_MOUSE, Font.BOLD, 25));
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_MOUSE_R,Utility.HEAD_FG_COLOR_MOUSE_G,Utility.HEAD_FG_COLOR_MOUSE_B));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 25));
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
			}
		});
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 25));
		
		ans = new JLabel("Add New Student");
		ans.setIcon(new ImageIcon(Img.OK));
		ans.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		ans.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		ans.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
		ans.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
				new PaddNewStudent().setVisible(true);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				ans.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				ans.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				ans.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				ans.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
		ans.setBounds(12, 348, 210, 16);
		contentPane.add(ans);
		
		JLabel ds = new JLabel("Delete Student");
		ds.setBounds(12, 377, 210, 16);
		contentPane.add(ds);
		ds.setIcon(new ImageIcon(Img.OK));
		ds.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		ds.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		ds.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
		ds.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
				new PDeleteStudent().setVisible(true);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				ds.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				ds.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				ds.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				ds.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
		
		JLabel us = new JLabel("Update Student");
		us.setBounds(12, 406, 210, 16);
		contentPane.add(us);
		us.setIcon(new ImageIcon(Img.OK));
		us.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		us.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		us.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
		us.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
				new PUpdateStudent().setVisible(true);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				us.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				us.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				us.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				us.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
		
		JLabel vsd = new JLabel("View Student Detail");
		vsd.setBounds(236, 435, 241, 16);
		contentPane.add(vsd);
		vsd.setIcon(new ImageIcon(Img.OK));
		vsd.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		vsd.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		vsd.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
		vsd.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
				new PStudentDetail().setVisible(true);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				vsd.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				vsd.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				vsd.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				vsd.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
		
		JLabel sfd = new JLabel("Student Fee Detail");
		sfd.setBounds(12, 435, 210, 16);
		contentPane.add(sfd);
		sfd.setIcon(new ImageIcon(Img.OK));
		sfd.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		sfd.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		sfd.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
		sfd.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
				new PStudentFeeDetail().setVisible(true);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				sfd.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				sfd.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				sfd.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				sfd.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
		
		JLabel fs = new JLabel("Fee Structure");
		fs.setBounds(236, 348, 253, 16);
		contentPane.add(fs);
		fs.setIcon(new ImageIcon(Img.OK));
		fs.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		fs.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		fs.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
		fs.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
				new PSetFeeManagement().setVisible(true);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				fs.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				fs.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				fs.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				fs.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
		
		JLabel fp = new JLabel("Fee Pay");
		fp.setBounds(236, 406, 253, 16);
		contentPane.add(fp);
		fp.setIcon(new ImageIcon(Img.OK));
		fp.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		fp.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		fp.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
		fp.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
				new PFeePay().setVisible(true);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				fp.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				fp.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				fp.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				fp.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
		
		JLabel asf = new JLabel("All Student Fee");
		asf.setBounds(236, 377, 253, 16);
		contentPane.add(asf);
		asf.setIcon(new ImageIcon(Img.OK));
		asf.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		asf.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		asf.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
		
		

		asf.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
				new PViewAllStudent().setVisible(true);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				asf.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				asf.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				asf.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				asf.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});



		JLabel da = new JLabel("Delete Accontant");
		da.setBounds(12, 464, 221, 16);
		contentPane.add(da);
		da.setIcon(new ImageIcon(Img.OK));
		da.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		da.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		da.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
		
		da.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
				new DeleteAccountant().setVisible(true);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				da.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				da.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				da.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				da.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});




		JLabel aal = new JLabel("All Accountant List");
		aal.setBounds(236, 464, 241, 16);
		contentPane.add(aal);
		aal.setIcon(new ImageIcon(Img.OK));
		aal.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		aal.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		aal.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));

		aal.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
				new ViewAllAccountant().setVisible(true);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				aal.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				aal.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				aal.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				aal.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});



		JLabel logout = new JLabel("Logout");
		logout.setBounds(160, 493, 150, 16);
		contentPane.add(logout);
		logout.setIcon(new ImageIcon(Img.OK));
		logout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		logout.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		logout.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Img.ACCOUNTANT_LOGIN));
		label.setBounds(105, 62, 310, 261);
		contentPane.add(label);
		
		
		logout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
				new Main_activity();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				logout.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				logout.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				logout.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				logout.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
	}
	public void dispose1(){
		this.dispose();
	}
}
