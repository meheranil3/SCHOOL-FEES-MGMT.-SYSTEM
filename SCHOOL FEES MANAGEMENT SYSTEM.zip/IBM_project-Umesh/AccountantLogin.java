import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.EventQueue;
import java.sql.*;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Cursor;
import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

class AccountantLogin extends JFrame implements ActionListener{
	JButton submit;
	JLabel head;
	JTextField usert;
	JPasswordField passt;
	private JLabel label;
	private JLabel label_1;
	private JLabel lblNewLabel;
	private JLabel forgot;
	private JLabel newAccountant;
	private JLabel backl;

	AccountantLogin(){
		setResizable(false);
		setTitle("Principal Login");
		setLocation(200,100);
		setVisible(true);
		setSize(433,600);
		getContentPane().setBackground(new Color(Utility.BKCOLOR_R,Utility.BKCOLOR_G,Utility.BKCOLOR_B));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		submit = new JButton("Sign Up");
		submit.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER) {
					submit.doClick();
				}
			}
		});
		submit.setBackground(new Color(Utility.BTNCOLOR_R,Utility.BTNCOLOR_G,Utility.BTNCOLOR_B));
		submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		submit.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		submit.setIcon(new ImageIcon(Img.SIGN_UP));
		submit.setBounds(194, 427, 100, 20);
		head = new JLabel(" ACCOUNTANT LOGIN!!!");
		head.setHorizontalAlignment(SwingConstants.CENTER);
		head.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				head.setFont(new Font(Utility.HEAD_FONT_MOUSE, Font.BOLD, 20));
				head.setForeground(new Color(Utility.HEAD_FG_COLOR_MOUSE_R,Utility.HEAD_FG_COLOR_MOUSE_G,Utility.HEAD_FG_COLOR_MOUSE_B));
			}
			@Override
			public void mouseExited(MouseEvent e) {
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));
			}
		});
		head.setForeground(new Color(Utility.HEAD_FG_COLOR_R,Utility.HEAD_FG_COLOR_G,Utility.HEAD_FG_COLOR_B));
		head.setFont(new Font(Utility.HEAD_FONT, Font.BOLD, 20));

		head.setBounds(27, 13, 374, 40);
		usert = new JTextField();
		usert.setBounds(160, 351, 200, 20);
		passt = new JPasswordField();
		passt.setBounds(160, 384, 200, 20);
		getContentPane().setLayout(null);


		getContentPane().add(submit);
		getContentPane().add(head);
		getContentPane().add(usert);
		getContentPane().add(passt);
		getRootPane().setDefaultButton(submit);
		label = new JLabel("");
		label.setBounds(95, 61, 265, 256);
		label.setIcon(new ImageIcon(Img.LOGIN_LOGO));
		getContentPane().add(label);
		
		label_1 = new JLabel("");
		label_1.setBounds(134, 353, 24, 16);
		label_1.setIcon(new ImageIcon(Img.USERNAME));
		getContentPane().add(label_1);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(136, 386, 24, 18);
		lblNewLabel.setIcon(new ImageIcon(Img.PASSWORD));
		getContentPane().add(lblNewLabel);
		
		forgot = new JLabel("Fogot Password");
		forgot.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		forgot.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
			new AccountantForgotPassword();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				forgot.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				forgot.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
			}
		});
		forgot.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		forgot.setFont(new Font("Tahoma", Font.PLAIN, 9));
		forgot.setBounds(293, 408, 67, 16);
		getContentPane().add(forgot);
		
		newAccountant = new JLabel("Add new Accountant");
		newAccountant.setIcon(new ImageIcon(Img.OK));
		newAccountant.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		newAccountant.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		newAccountant.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				newAccountant.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				newAccountant.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
			new PricipalCrediantialNewAccountant();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				newAccountant.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				newAccountant.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
		newAccountant.setBounds(14, 495, 232, 16);
		getContentPane().add(newAccountant);
		
		backl = new JLabel("Back");
		backl.setIcon(new ImageIcon(Img.OK));
		backl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backl.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		backl.setBackground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
		backl.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				backl.setForeground(new Color(Utility.LINK_COLOR_MOUSE_R,Utility.LINK_COLOR_MOUSE_G,Utility.LINK_COLOR_MOUSE_B));
				backl.setFont(new Font(Utility.LINK_FONT_MOUSE, Font.BOLD, 20));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose1();
            new Main_activity();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				backl.setForeground(new Color(Utility.LINK_COLOR_R,Utility.LINK_COLOR_G,Utility.LINK_COLOR_B));
				backl.setFont(new Font(Utility.LINK_FONT, Font.BOLD, 15));
			}
		});
		backl.setBounds(12, 524, 80, 16);
		getContentPane().add(backl);

		submit.addActionListener(this);

	}	
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==submit){
			String userN =usert.getText();
			String userP = new String(passt.getPassword());
			if(userN.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your user name");
			}
			else if(userP.isEmpty()){
				JOptionPane.showMessageDialog(this,"Enter your Password");
			}
			else{
				try
          		{
            	   Class.forName(DbConstant.CLASS_NAME);
            	   Connection con = DriverManager.getConnection(DbConstant.CONNECTION,DbConstant.DATABASE_NAME,DbConstant.DATABASE_PASSWORD);
            	   Statement st = con.createStatement();


            	   String query = "create table accountant("+
										"name varchar2(50),"+
										"father_name varchar2(50),"+
										"mother_name varchar2(50),"+
										"Highest_Qualification varchar2(50),"+
										"email varchar2(100),"+
										"security_Question varchar2(500),"+
										"security_Answer varchar2(1000),"+
										"user_name varchar2(100) not null primary key,"+
										"password varchar2(100)"+
										")"; 
					try{
						st.executeUpdate(query);
						query = "INSERT INTO accountant VALUES ('Umesh' , 'xyz' , 'zyx' , "+
						"'undergraduate' , 'umeshdangrecha240@gmail.com' , "+
						"'What was your childhood nickname?' , "+
						"'Umesh' , 'Umesh' , 'Umesh' )";
						st.executeUpdate(query);
					}
					catch (Exception create){
					}

            	    query= "select user_name,password from accountant";
            	   ResultSet rs = st.executeQuery(query);
            	   boolean flag=false;
            	   while(rs.next()){
            	   	String user = rs.getString("user_name");
            	   	String pass = rs.getString("password");
            	   	if(userN.equals(user)&&userP.equals(pass)){
            	   		flag = true;
            	   		break;
            	   	}
            	   }

            	   if(flag){
            	   		con.close();
            	   		JOptionPane.showMessageDialog(this,"Successfully Login!");
            	   		this.dispose();
            	   		new AccountantLoginPage().setVisible(true);
            	   	}
            	   	else{
            	   		JOptionPane.showMessageDialog(this,"Wrong username and password");
            	   	}
            	   	con.close();
           		}	
           		catch(Exception ev){
           			System.out.println(ev);
           		}
           	}	
		}
		
	}
	public void dispose1(){
		this.dispose();
	}
	public static void main(String args[]){
		EventQueue.invokeLater(new Runnable()  {
			public void run() {
				try {
					AccountantLogin frame = new AccountantLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


}